import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertTaskSchema, insertEventSchema, insertTrackSchema, insertDeadlineSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import aiRouter from "./routes/ai";
import spotifyRouter from "./routes/spotify";

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handling middleware
  app.use((err: any, req: any, res: any, next: any) => {
    console.error(err);
    if (err instanceof ZodError) {
      const validationError = fromZodError(err);
      return res.status(400).json({ error: validationError.message });
    }
    res.status(500).json({ error: err.message || "Internal server error" });
  });

  // User Routes
  app.get("/api/user", async (req, res) => {
    // For demo purposes, we'll return a mock user
    const user = await storage.getDefaultUser();
    res.json(user);
  });

  // Task Routes
  app.get("/api/tasks", async (req, res) => {
    const tasks = await storage.getAllTasks();
    const groupedTasks = {
      todo: tasks.filter(task => task.status === "todo"),
      inProgress: tasks.filter(task => task.status === "inProgress"),
      completed: tasks.filter(task => task.status === "completed"),
      currentTask: tasks.find(task => task.status === "inProgress")
    };
    res.json(groupedTasks);
  });

  app.post("/api/tasks", async (req, res, next) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const userId = 1; // Default user for demo
      const newTask = await storage.createTask({ ...taskData, userId });
      res.status(201).json(newTask);
    } catch (error) {
      next(error);
    }
  });

  app.patch("/api/tasks/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const updateSchema = z.object({
        status: z.string().optional(),
        progress: z.number().optional(),
        name: z.string().optional(),
        description: z.string().optional(),
        dueDate: z.string().optional(),
        project: z.string().optional(),
        duration: z.string().optional(),
        tags: z.string().optional(),
      });
      
      const updateData = updateSchema.parse(req.body);
      const updatedTask = await storage.updateTask(id, updateData);
      
      if (!updatedTask) {
        return res.status(404).json({ error: "Task not found" });
      }
      
      res.json(updatedTask);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/tasks/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteTask(id);
      
      if (!success) {
        return res.status(404).json({ error: "Task not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  });

  // Schedule Routes
  app.get("/api/schedule", async (req, res) => {
    const events = await storage.getAllEvents();
    res.json({ events });
  });

  app.post("/api/events", async (req, res, next) => {
    try {
      const eventData = insertEventSchema.parse(req.body);
      const userId = 1; // Default user for demo
      const newEvent = await storage.createEvent({ ...eventData, userId });
      res.status(201).json(newEvent);
    } catch (error) {
      next(error);
    }
  });

  // AI Routes
  app.use("/api/ai", aiRouter);
  
  // Spotify Routes
  app.use("/api/spotify", spotifyRouter);

  // Stats Routes
  app.get("/api/stats", async (req, res) => {
    const stats = await storage.getProductivityStats();
    res.json(stats);
  });

  // Music Routes
  app.get("/api/music/tracks", async (req, res) => {
    const tracks = await storage.getAllTracks();
    res.json({ tracks });
  });

  app.post("/api/music/tracks", async (req, res, next) => {
    try {
      const trackData = insertTrackSchema.parse(req.body);
      const newTrack = await storage.createTrack(trackData);
      res.status(201).json(newTrack);
    } catch (error) {
      next(error);
    }
  });

  // Deadlines Routes
  app.get("/api/deadlines", async (req, res) => {
    const deadlines = await storage.getAllDeadlines();
    res.json({ deadlines });
  });

  app.post("/api/deadlines", async (req, res, next) => {
    try {
      const deadlineData = insertDeadlineSchema.parse(req.body);
      const userId = 1; // Default user for demo
      const newDeadline = await storage.createDeadline({ ...deadlineData, userId });
      res.status(201).json(newDeadline);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
