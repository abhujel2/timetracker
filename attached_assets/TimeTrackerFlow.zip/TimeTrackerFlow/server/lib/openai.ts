import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface TaskRecommendation {
  name: string;
  description: string;
  priority: "high" | "medium" | "low";
  estimatedDuration: string;
  category: string;
  suggestedTimeSlot?: string;
}

export interface ProductivityInsight {
  title: string;
  description: string;
  actionItem?: string;
}

export interface AIResponse {
  tasks?: TaskRecommendation[];
  schedule?: any[];
  insights?: ProductivityInsight[];
  message?: string;
}

/**
 * Generate task recommendations based on user's current tasks, schedule, and goals
 */
export async function generateTaskRecommendations(
  currentTasks: any[],
  completedTasks: any[],
  schedule: any[],
  preferences: any
): Promise<TaskRecommendation[]> {
  try {
    const prompt = `
      As an AI productivity assistant, please analyze the user's current workload and recommend 3 tasks they should prioritize next.
      
      Current tasks: ${JSON.stringify(currentTasks)}
      Completed tasks: ${JSON.stringify(completedTasks)}
      Current schedule: ${JSON.stringify(schedule)}
      User preferences: ${JSON.stringify(preferences)}
      
      Based on this information, recommend 3 high-value tasks the user should focus on next.
      Provide task name, description, priority level (high/medium/low), estimated duration, 
      and optimal time slot where applicable.
      
      Return the recommendations in JSON format with an array of tasks 
      where each task has: name, description, priority, estimatedDuration, category, and suggestedTimeSlot properties.
    `;

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    const parsedResponse = JSON.parse(content);
    return parsedResponse.tasks || [];
  } catch (error) {
    console.error("Error generating task recommendations:", error);
    return [];
  }
}

/**
 * Generate an optimal schedule based on tasks, preferences, and constraints
 */
export async function generateOptimalSchedule(
  tasks: any[],
  preferences: any,
  constraints: any
): Promise<any[]> {
  try {
    const prompt = `
      As an AI scheduling assistant, please create an optimal daily schedule for the user.
      
      Tasks to schedule: ${JSON.stringify(tasks)}
      User preferences: ${JSON.stringify(preferences)}
      Constraints: ${JSON.stringify(constraints)}
      
      Based on this information, create a schedule that:
      1. Prioritizes high-value tasks
      2. Respects the user's energy levels and focus times
      3. Includes appropriate breaks
      4. Groups similar tasks when possible
      5. Allocates realistic time for each task
      
      Return the schedule in JSON format as an array of time blocks, 
      where each block has: startTime, endTime, taskId (if applicable), type (work/break/meeting), and notes properties.
    `;

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    const parsedResponse = JSON.parse(content);
    return parsedResponse.schedule || [];
  } catch (error) {
    console.error("Error generating optimal schedule:", error);
    return [];
  }
}

/**
 * Analyze productivity patterns and provide insights
 */
export async function analyzeProductivityPatterns(
  completedTasks: any[],
  focusSessions: any[],
  timeTracking: any[]
): Promise<ProductivityInsight[]> {
  try {
    const prompt = `
      As an AI productivity analyst, please analyze the user's work patterns and provide helpful insights.
      
      Completed tasks: ${JSON.stringify(completedTasks)}
      Focus sessions: ${JSON.stringify(focusSessions)}
      Time tracking data: ${JSON.stringify(timeTracking)}
      
      Based on this data, identify:
      1. Productivity patterns (when the user is most productive)
      2. Potential inefficiencies or time sinks
      3. Successful strategies the user has employed
      4. Specific recommendations for improvement
      
      Return the analysis in JSON format as an array of insights, 
      where each insight has: title, description, and actionItem properties.
    `;

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    const parsedResponse = JSON.parse(content);
    return parsedResponse.insights || [];
  } catch (error) {
    console.error("Error analyzing productivity patterns:", error);
    return [];
  }
}

/**
 * Process a natural language request related to productivity
 */
export async function processProductivityRequest(
  request: string,
  userData: any
): Promise<AIResponse> {
  try {
    const prompt = `
      As an AI productivity assistant, please respond to the following user request:
      
      User request: "${request}"
      
      User data context:
      ${JSON.stringify(userData)}
      
      Based on the request, provide a helpful response that could include:
      - Task recommendations
      - Schedule adjustments
      - Productivity insights
      - Direct answers to questions
      
      Return your response in JSON format with any of these optional properties:
      - tasks: array of task recommendations
      - schedule: array of schedule blocks
      - insights: array of productivity insights
      - message: a direct text response to the user
    `;

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    return JSON.parse(content);
  } catch (error) {
    console.error("Error processing productivity request:", error);
    return { message: "I had trouble processing your request. Please try again." };
  }
}

export default {
  generateTaskRecommendations,
  generateOptimalSchedule,
  analyzeProductivityPatterns,
  processProductivityRequest,
};