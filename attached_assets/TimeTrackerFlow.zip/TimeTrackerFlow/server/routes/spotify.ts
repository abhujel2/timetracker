import { Router, Request, Response } from "express";
import fetch from "node-fetch";

// Spotify API credentials would be loaded from environment variables in a production setup
// We'll need to ask the user to provide these secrets
const SPOTIFY_CLIENT_ID = process.env.SPOTIFY_CLIENT_ID;
const SPOTIFY_CLIENT_SECRET = process.env.SPOTIFY_CLIENT_SECRET;

const router = Router();

/**
 * Get a Spotify API access token using client credentials flow
 * This endpoint should be called from the frontend when needed
 */
router.get("/token", async (req: Request, res: Response) => {
  try {
    // Check if Spotify credentials are available
    if (!SPOTIFY_CLIENT_ID || !SPOTIFY_CLIENT_SECRET) {
      return res.status(500).json({ 
        error: "Spotify API credentials not configured. Please add SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET to environment variables." 
      });
    }

    // Prepare credentials for Basic Auth
    const credentials = Buffer.from(`${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`).toString("base64");

    // Make request to Spotify API to get access token
    const response = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${credentials}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: "grant_type=client_credentials",
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error("Spotify API error:", errorData);
      return res.status(response.status).json({ 
        error: "Failed to get Spotify access token", 
        details: errorData 
      });
    }

    // Get token from response
    const data = await response.json();
    
    // Return token to client
    return res.json({
      access_token: data.access_token,
      token_type: data.token_type,
      expires_in: data.expires_in,
    });
  } catch (error) {
    console.error("Error getting Spotify token:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * Search for tracks on Spotify
 */
router.get("/search", async (req: Request, res: Response) => {
  try {
    const { query } = req.query;
    
    if (!query) {
      return res.status(400).json({ error: "Query parameter is required" });
    }
    
    // Get token first
    const tokenResponse = await fetch("http://localhost:5000/api/spotify/token");
    if (!tokenResponse.ok) {
      return res.status(tokenResponse.status).json({ error: "Failed to get Spotify token" });
    }
    
    const tokenData = await tokenResponse.json();
    
    // Make search request to Spotify API
    const searchResponse = await fetch(
      `https://api.spotify.com/v1/search?q=${encodeURIComponent(query as string)}&type=track&limit=10`,
      {
        headers: {
          "Authorization": `Bearer ${tokenData.access_token}`,
        },
      }
    );
    
    if (!searchResponse.ok) {
      return res.status(searchResponse.status).json({ error: "Spotify search failed" });
    }
    
    const searchData = await searchResponse.json();
    return res.json(searchData);
  } catch (error) {
    console.error("Error searching Spotify:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * Get recommendations based on seed tracks, artists, or genres
 */
router.get("/recommendations", async (req: Request, res: Response) => {
  try {
    const { seed_tracks, seed_artists, seed_genres } = req.query;
    
    // At least one seed parameter is required
    if (!seed_tracks && !seed_artists && !seed_genres) {
      return res.status(400).json({ 
        error: "At least one seed parameter (seed_tracks, seed_artists, or seed_genres) is required" 
      });
    }
    
    // Get token first
    const tokenResponse = await fetch("http://localhost:5000/api/spotify/token");
    if (!tokenResponse.ok) {
      return res.status(tokenResponse.status).json({ error: "Failed to get Spotify token" });
    }
    
    const tokenData = await tokenResponse.json();
    
    // Build query params
    const params = new URLSearchParams();
    if (seed_tracks) params.append("seed_tracks", seed_tracks as string);
    if (seed_artists) params.append("seed_artists", seed_artists as string);
    if (seed_genres) params.append("seed_genres", seed_genres as string);
    params.append("limit", "20");
    
    // Make recommendations request to Spotify API
    const recommendationsResponse = await fetch(
      `https://api.spotify.com/v1/recommendations?${params.toString()}`,
      {
        headers: {
          "Authorization": `Bearer ${tokenData.access_token}`,
        },
      }
    );
    
    if (!recommendationsResponse.ok) {
      return res.status(recommendationsResponse.status).json({ error: "Spotify recommendations failed" });
    }
    
    const recommendationsData = await recommendationsResponse.json();
    return res.json(recommendationsData);
  } catch (error) {
    console.error("Error getting Spotify recommendations:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * Get tracks from a specific Spotify playlist
 */
router.get("/playlist/:id", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // Get token first
    const tokenResponse = await fetch("http://localhost:5000/api/spotify/token");
    if (!tokenResponse.ok) {
      return res.status(tokenResponse.status).json({ error: "Failed to get Spotify token" });
    }
    
    const tokenData = await tokenResponse.json();
    
    // Get playlist tracks from Spotify API
    const playlistResponse = await fetch(
      `https://api.spotify.com/v1/playlists/${id}/tracks?limit=20`,
      {
        headers: {
          "Authorization": `Bearer ${tokenData.access_token}`,
        },
      }
    );
    
    if (!playlistResponse.ok) {
      return res.status(playlistResponse.status).json({ error: "Failed to get playlist tracks" });
    }
    
    const playlistData = await playlistResponse.json();
    return res.json(playlistData);
  } catch (error) {
    console.error("Error getting playlist tracks:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;