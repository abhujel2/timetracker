import { Router } from "express";
import { z } from "zod";
import openaiClient, { AIResponse } from "../lib/openai";
import { storage } from "../storage";

const aiRouter = Router();

// Schema for generating task recommendations
const taskRecommendationsSchema = z.object({
  preferences: z.object({
    focusTime: z.string().optional(),
    taskTypes: z.array(z.string()).optional(),
    workStyle: z.string().optional(),
  }).optional(),
});

// Schema for generating an optimal schedule
const scheduleGenerationSchema = z.object({
  date: z.string().optional(),
  constraints: z.object({
    startTime: z.string().optional(),
    endTime: z.string().optional(),
    breaks: z.array(z.object({
      duration: z.string(),
      preferred: z.boolean().optional(),
    })).optional(),
  }).optional(),
});

// Schema for analyzing productivity
const productivityAnalysisSchema = z.object({
  timeframe: z.string().optional(),
});

// Schema for processing natural language requests
const nlpRequestSchema = z.object({
  request: z.string(),
});

// Generate task recommendations based on current tasks and user preferences
aiRouter.post("/recommendations", async (req, res, next) => {
  try {
    const { preferences } = taskRecommendationsSchema.parse(req.body);
    
    // Get user's current context
    const tasks = await storage.getAllTasks();
    const events = await storage.getAllEvents();
    
    const currentTasks = tasks.filter(task => task.status !== "completed");
    const completedTasks = tasks.filter(task => task.status === "completed");
    
    // Call OpenAI to generate recommendations
    const recommendations = await openaiClient.generateTaskRecommendations(
      currentTasks,
      completedTasks,
      events,
      preferences || {}
    );
    
    res.json({ recommendations });
  } catch (error) {
    next(error);
  }
});

// Generate an optimal schedule
aiRouter.post("/schedule", async (req, res, next) => {
  try {
    const { date, constraints } = scheduleGenerationSchema.parse(req.body);
    
    // Get all tasks that need scheduling
    const tasks = await storage.getAllTasks();
    const events = await storage.getAllEvents();
    
    // Default preferences
    const preferences = {
      focusTimePreference: "morning",
      workBlocks: {
        ideal: "90m",
        max: "120m",
      },
      taskPrioritization: "deadline-first",
    };
    
    // Generate optimal schedule
    const constraintsObj = constraints ? { existingEvents: events, ...constraints } : { existingEvents: events };
    const schedule = await openaiClient.generateOptimalSchedule(
      tasks.filter(task => task.status !== "completed"),
      preferences,
      constraintsObj
    );
    
    res.json({ schedule, date: date || new Date().toISOString().split('T')[0] });
  } catch (error) {
    next(error);
  }
});

// Analyze productivity patterns
aiRouter.post("/insights", async (req, res, next) => {
  try {
    const { timeframe } = productivityAnalysisSchema.parse(req.body);
    
    // Get relevant data for analysis
    const tasks = await storage.getAllTasks();
    const completedTasks = tasks.filter(task => task.status === "completed");
    
    // Mock data for focus sessions and time tracking
    // In a real implementation, we'd get this from the database
    const focusSessions: any[] = [];
    const timeTracking: any[] = [];
    
    // Generate productivity insights
    const insights = await openaiClient.analyzeProductivityPatterns(
      completedTasks,
      focusSessions,
      timeTracking
    );
    
    res.json({ insights, timeframe: timeframe || "last 7 days" });
  } catch (error) {
    next(error);
  }
});

// Process natural language requests
aiRouter.post("/query", async (req, res, next) => {
  try {
    const { request } = nlpRequestSchema.parse(req.body);
    
    if (!request.trim()) {
      return res.status(400).json({ error: "Request cannot be empty" });
    }
    
    // Get user context
    const user = await storage.getDefaultUser();
    const tasks = await storage.getAllTasks();
    const events = await storage.getAllEvents();
    const stats = await storage.getProductivityStats();
    
    // Build context for the AI
    const userData = {
      user,
      tasks: {
        todo: tasks.filter(task => task.status === "todo"),
        inProgress: tasks.filter(task => task.status === "inProgress"),
        completed: tasks.filter(task => task.status === "completed"),
      },
      schedule: events,
      stats,
    };
    
    // Process the natural language request
    const response: AIResponse = await openaiClient.processProductivityRequest(
      request,
      userData
    );
    
    res.json(response);
  } catch (error) {
    next(error);
  }
});

export default aiRouter;