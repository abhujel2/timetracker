import { 
  User, InsertUser, Task, InsertTask, Event, InsertEvent, 
  Track, InsertTrack, Deadline, InsertDeadline, 
  TimeDistribution, WeeklyDataPoint, Stats 
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getDefaultUser(): Promise<User>;
  
  // Tasks
  getAllTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask & { userId: number }): Promise<Task>;
  updateTask(id: number, updateData: Partial<Task>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  // Events
  getAllEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent & { userId: number }): Promise<Event>;
  
  // Music
  getAllTracks(): Promise<Track[]>;
  getTrack(id: number): Promise<Track | undefined>;
  createTrack(track: InsertTrack): Promise<Track>;
  
  // Deadlines
  getAllDeadlines(): Promise<Deadline[]>;
  getDeadline(id: number): Promise<Deadline | undefined>;
  createDeadline(deadline: InsertDeadline & { userId: number }): Promise<Deadline>;
  
  // Stats
  getProductivityStats(): Promise<Stats>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private events: Map<number, Event>;
  private tracks: Map<number, Track>;
  private deadlines: Map<number, Deadline>;
  
  private userId: number;
  private taskId: number;
  private eventId: number;
  private trackId: number;
  private deadlineId: number;

  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.events = new Map();
    this.tracks = new Map();
    this.deadlines = new Map();
    
    this.userId = 1;
    this.taskId = 1;
    this.eventId = 1;
    this.trackId = 1;
    this.deadlineId = 1;
    
    // Initialize with demo data
    this.initDemoData();
  }

  private initDemoData() {
    // Default user
    const defaultUser: User = {
      id: this.userId++,
      username: "John Doe",
      password: "hashed_password", // In a real app, this would be hashed
      title: "Product Designer",
      focusedTimeToday: 266, // 4h 26m in minutes
      focusedTimeGoal: 390, // 6h 30m in minutes
      focusedTimePercentage: 68,
      focusedTimeChange: "+18%"
    };
    this.users.set(defaultUser.id, defaultUser);
    
    // Sample tasks
    const tasks: Array<Omit<Task, "id">> = [
      {
        name: "Design system update",
        description: "Update color palette and typography",
        status: "todo",
        project: "Internal",
        duration: "45m",
        progress: 0,
        dueDate: "Today, 2:00 PM",
        completedAt: null,
        userId: defaultUser.id,
        tags: "Design",
        createdAt: new Date()
      },
      {
        name: "Content review",
        description: "Review blog post drafts",
        status: "todo",
        project: "Marketing",
        duration: "1h 30m",
        progress: 0,
        dueDate: "Today, 4:00 PM",
        completedAt: null,
        userId: defaultUser.id,
        tags: "Content",
        createdAt: new Date()
      },
      {
        name: "Team meeting",
        description: "Weekly sprint planning",
        status: "todo",
        project: "Team",
        duration: "1h",
        progress: 0,
        dueDate: "Tomorrow, 9:00 AM",
        completedAt: null,
        userId: defaultUser.id,
        tags: "Meeting",
        createdAt: new Date()
      },
      {
        name: "Website Redesign",
        description: "Homepage and product pages",
        status: "inProgress",
        project: "Client Project",
        duration: "2h 15m",
        progress: 65,
        dueDate: "Today, 12:00 PM",
        completedAt: null,
        userId: defaultUser.id,
        tags: "Design",
        createdAt: new Date()
      },
      {
        name: "Client presentation",
        description: "Prepare slides for quarterly review",
        status: "inProgress",
        project: "Client",
        duration: "1h 45m",
        progress: 30,
        dueDate: "Tomorrow, 11:00 AM",
        completedAt: null,
        userId: defaultUser.id,
        tags: "Client",
        createdAt: new Date()
      },
      {
        name: "Client email",
        description: "Send project update",
        status: "completed",
        project: "Client",
        duration: "30m",
        progress: 100,
        dueDate: "Today, 9:30 AM",
        completedAt: "Today, 9:30 AM",
        userId: defaultUser.id,
        tags: "Email",
        createdAt: new Date()
      },
      {
        name: "Bug fixes",
        description: "Fix responsive layout issues",
        status: "completed",
        project: "Development",
        duration: "45m",
        progress: 100,
        dueDate: "Today, 10:15 AM",
        completedAt: "Today, 10:15 AM",
        userId: defaultUser.id,
        tags: "Development",
        createdAt: new Date()
      },
      {
        name: "Research",
        description: "Competitor analysis",
        status: "completed",
        project: "Marketing",
        duration: "1h",
        progress: 100,
        dueDate: "Yesterday, 4:45 PM",
        completedAt: "Yesterday, 4:45 PM",
        userId: defaultUser.id,
        tags: "Research",
        createdAt: new Date()
      }
    ];
    
    tasks.forEach(task => {
      const id = this.taskId++;
      this.tasks.set(id, { ...task, id });
    });
    
    // Sample events
    const events: Array<Omit<Event, "id">> = [
      {
        title: "Team Standup Meeting",
        description: "Zoom Meeting",
        timeRange: "9:00 AM - 9:30 AM",
        date: "Today",
        category: "meeting",
        userId: defaultUser.id,
        createdAt: new Date()
      },
      {
        title: "Design Sprint",
        description: "Deep Work Session",
        timeRange: "10:00 AM - 12:00 PM",
        date: "Today",
        category: "focus",
        userId: defaultUser.id,
        createdAt: new Date()
      },
      {
        title: "Client Meeting",
        description: "Project Review",
        timeRange: "2:00 PM - 3:00 PM",
        date: "Today",
        category: "client",
        userId: defaultUser.id,
        createdAt: new Date()
      },
      {
        title: "Project Planning",
        description: "Quarterly Goals",
        timeRange: "4:00 PM - 5:30 PM",
        date: "Today",
        category: "planning",
        userId: defaultUser.id,
        createdAt: new Date()
      }
    ];
    
    events.forEach(event => {
      const id = this.eventId++;
      this.events.set(id, { ...event, id });
    });
    
    // Sample tracks
    const tracks: Array<Omit<Track, "id">> = [
      {
        title: "Ambient Focus",
        artist: "Productivity Playlist",
        audioUrl: "https://cdn.example.com/music/ambient-focus.mp3",
        coverUrl: "https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
        duration: 270, // 4:30
        category: "focus"
      },
      {
        title: "Deep Focus",
        artist: "Ambient Study",
        audioUrl: "https://cdn.example.com/music/deep-focus.mp3",
        coverUrl: "https://images.unsplash.com/photo-1494232410401-ad00d5433cfa?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
        duration: 225, // 3:45
        category: "focus"
      },
      {
        title: "Coding Mode",
        artist: "Electronic Focus",
        audioUrl: "https://cdn.example.com/music/coding-mode.mp3",
        coverUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
        duration: 252, // 4:12
        category: "productivity"
      },
      {
        title: "Calm Waters",
        artist: "Nature Sounds",
        audioUrl: "https://cdn.example.com/music/calm-waters.mp3",
        coverUrl: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80",
        duration: 330, // 5:30
        category: "relax"
      }
    ];
    
    tracks.forEach(track => {
      const id = this.trackId++;
      this.tracks.set(id, { ...track, id });
    });
    
    // Sample deadlines
    const deadlines: Array<Omit<Deadline, "id">> = [
      {
        title: "Client Project Delivery",
        dueDate: "Jul 15, 2023",
        daysLeft: 2,
        progress: 85,
        userId: defaultUser.id,
        createdAt: new Date()
      },
      {
        title: "Marketing Campaign",
        dueDate: "Jul 18, 2023",
        daysLeft: 5,
        progress: 60,
        userId: defaultUser.id,
        createdAt: new Date()
      },
      {
        title: "Team Presentation",
        dueDate: "Jul 23, 2023",
        daysLeft: 10,
        progress: 35,
        userId: defaultUser.id,
        createdAt: new Date()
      }
    ];
    
    deadlines.forEach(deadline => {
      const id = this.deadlineId++;
      this.deadlines.set(id, { ...deadline, id });
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { 
      ...insertUser, 
      id,
      focusedTimeToday: 0,
      focusedTimeGoal: 390, // 6h 30m default
      focusedTimePercentage: 0,
      focusedTimeChange: "0%"
    };
    this.users.set(id, user);
    return user;
  }
  
  async getDefaultUser(): Promise<User> {
    return this.users.get(1) as User;
  }

  // Task methods
  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }

  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(task: InsertTask & { userId: number }): Promise<Task> {
    const id = this.taskId++;
    const newTask: Task = {
      ...task,
      id,
      completedAt: null,
      createdAt: new Date(),
      progress: task.progress || 0
    };
    this.tasks.set(id, newTask);
    return newTask;
  }

  async updateTask(id: number, updateData: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask: Task = { ...task, ...updateData };
    
    // Handle status changes and completion
    if (updateData.status === "completed" && task.status !== "completed") {
      updatedTask.completedAt = new Date().toLocaleString();
      updatedTask.progress = 100;
    }
    
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  // Event methods
  async getAllEvents(): Promise<Event[]> {
    return Array.from(this.events.values());
  }

  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(event: InsertEvent & { userId: number }): Promise<Event> {
    const id = this.eventId++;
    const newEvent: Event = {
      ...event,
      id,
      createdAt: new Date()
    };
    this.events.set(id, newEvent);
    return newEvent;
  }

  // Music methods
  async getAllTracks(): Promise<Track[]> {
    return Array.from(this.tracks.values());
  }

  async getTrack(id: number): Promise<Track | undefined> {
    return this.tracks.get(id);
  }

  async createTrack(track: InsertTrack): Promise<Track> {
    const id = this.trackId++;
    const newTrack: Track = {
      ...track,
      id
    };
    this.tracks.set(id, newTrack);
    return newTrack;
  }

  // Deadline methods
  async getAllDeadlines(): Promise<Deadline[]> {
    return Array.from(this.deadlines.values());
  }

  async getDeadline(id: number): Promise<Deadline | undefined> {
    return this.deadlines.get(id);
  }

  async createDeadline(deadline: InsertDeadline & { userId: number }): Promise<Deadline> {
    const id = this.deadlineId++;
    const newDeadline: Deadline = {
      ...deadline,
      id,
      createdAt: new Date()
    };
    this.deadlines.set(id, newDeadline);
    return newDeadline;
  }

  // Stats methods
  async getProductivityStats(): Promise<Stats> {
    const timeDistribution: TimeDistribution[] = [
      { category: "Design", percentage: 45, color: "primary-500" },
      { category: "Development", percentage: 25, color: "secondary-400" },
      { category: "Meetings", percentage: 20, color: "accent-400" },
      { category: "Other", percentage: 10, color: "gray-400" },
    ];
    
    const weeklyData: WeeklyDataPoint[] = [
      { day: "Mon", totalHours: 3, productiveHours: 1.5 },
      { day: "Tue", totalHours: 8, productiveHours: 6 },
      { day: "Wed", totalHours: 11, productiveHours: 9.9 },
      { day: "Thu", totalHours: 7, productiveHours: 4.2 },
      { day: "Fri", totalHours: 9, productiveHours: 7.2 },
      { day: "Sat", totalHours: 5, productiveHours: 2 },
      { day: "Sun", totalHours: 2.5, productiveHours: 0.5 },
    ];
    
    return {
      timeDistribution,
      weeklyData,
      focusScore: 87,
      focusScoreChange: "+5%",
      tasksCompleted: "23/28",
      taskCompletionRate: "82%"
    };
  }
}

export const storage = new MemStorage();
