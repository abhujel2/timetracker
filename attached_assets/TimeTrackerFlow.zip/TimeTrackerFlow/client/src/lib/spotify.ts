import { Track } from '@shared/schema';
import { apiRequest } from './queryClient';

// Types for Spotify API responses
interface SpotifyTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

interface SpotifyTrack {
  id: string;
  name: string;
  duration_ms: number;
  artists: { name: string }[];
  album: {
    name: string;
    images: { url: string }[];
  };
  preview_url: string | null;
}

interface SpotifySearchResponse {
  tracks: {
    items: SpotifyTrack[];
  };
}

interface SpotifyRecommendationResponse {
  tracks: SpotifyTrack[];
}

interface SpotifyCachedToken {
  token: string;
  expiresAt: number;
}

// Cache for storing the Spotify token
let tokenCache: SpotifyCachedToken | null = null;

/**
 * Get a Spotify API token
 */
async function getToken(): Promise<string> {
  // Check if we have a valid cached token
  if (tokenCache && tokenCache.expiresAt > Date.now()) {
    return tokenCache.token;
  }

  try {
    // Get a new token from our backend
    const response = await fetch('/api/spotify/token');

    if (!response.ok) {
      throw new Error('Failed to get Spotify token');
    }

    const data: SpotifyTokenResponse = await response.json();
    
    // Cache the token with a 5-minute buffer before expiration
    tokenCache = {
      token: data.access_token,
      expiresAt: Date.now() + (data.expires_in - 300) * 1000, 
    };
    
    return data.access_token;
  } catch (error) {
    console.error('Error getting Spotify token:', error);
    throw error;
  }
}

/**
 * Make a request to the Spotify API
 */
async function spotifyRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  try {
    const token = await getToken();
    
    const response = await fetch(`https://api.spotify.com/v1${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      // Token might be expired, clear cache
      if (response.status === 401) {
        tokenCache = null;
        // Retry once with a new token
        return spotifyRequest(endpoint, options);
      }
      throw new Error(`Spotify API error: ${response.status}`);
    }

    return await response.json() as T;
  } catch (error) {
    console.error('Spotify API request failed:', error);
    throw error;
  }
}

/**
 * Search for tracks on Spotify
 */
export async function searchSpotifyTracks(query: string): Promise<Track[]> {
  try {
    const data = await spotifyRequest<SpotifySearchResponse>(
      `/search?q=${encodeURIComponent(query)}&type=track&limit=10`
    );
    
    // Convert Spotify track format to our Track format
    return data.tracks.items.map(convertSpotifyTrackToTrack);
  } catch (error) {
    console.error('Error searching Spotify tracks:', error);
    return [];
  }
}

/**
 * Get recommended tracks based on seed tracks, artists or genres
 */
export async function getSpotifyRecommendations(
  seedTracks?: string[], 
  seedArtists?: string[], 
  seedGenres?: string[]
): Promise<Track[]> {
  try {
    let params = new URLSearchParams();
    
    if (seedTracks && seedTracks.length > 0) {
      params.append('seed_tracks', seedTracks.join(','));
    }
    
    if (seedArtists && seedArtists.length > 0) {
      params.append('seed_artists', seedArtists.join(','));
    }
    
    if (seedGenres && seedGenres.length > 0) {
      params.append('seed_genres', seedGenres.join(','));
    }
    
    // If no seeds provided, use some default genres
    if (!params.toString()) {
      params.append('seed_genres', 'focus,ambient,classical,study');
    }
    
    params.append('limit', '20');
    
    const data = await spotifyRequest<SpotifyRecommendationResponse>(
      `/recommendations?${params.toString()}`
    );
    
    return data.tracks.map(convertSpotifyTrackToTrack);
  } catch (error) {
    console.error('Error getting Spotify recommendations:', error);
    return [];
  }
}

/**
 * Get productivity-focused playlists for concentration
 */
export async function getFocusPlaylists(): Promise<{ id: string, name: string, imageUrl: string }[]> {
  try {
    // Search for productivity playlists
    const response = await spotifyRequest<any>(
      `/search?q=productivity%20focus%20concentration&type=playlist&limit=6`
    );
    
    return response.playlists.items.map((playlist: any) => ({
      id: playlist.id,
      name: playlist.name,
      imageUrl: playlist.images[0]?.url || '',
    }));
  } catch (error) {
    console.error('Error getting focus playlists:', error);
    return [];
  }
}

/**
 * Get tracks from a specific playlist
 */
export async function getPlaylistTracks(playlistId: string): Promise<Track[]> {
  try {
    const response = await spotifyRequest<any>(
      `/playlists/${playlistId}/tracks?limit=20`
    );
    
    return response.items
      .filter((item: any) => item.track && item.track.preview_url) // Only include tracks with preview URLs
      .map((item: any) => convertSpotifyTrackToTrack(item.track));
  } catch (error) {
    console.error('Error getting playlist tracks:', error);
    return [];
  }
}

/**
 * Helper function to convert Spotify track format to our app's Track format
 */
function convertSpotifyTrackToTrack(spotifyTrack: SpotifyTrack): Track {
  return {
    id: parseInt(spotifyTrack.id.substring(0, 8), 16) || Math.floor(Math.random() * 10000),
    title: spotifyTrack.name,
    artist: spotifyTrack.artists.map(artist => artist.name).join(', '),
    duration: Math.round(spotifyTrack.duration_ms / 1000),
    audioUrl: spotifyTrack.preview_url || '',
    coverUrl: spotifyTrack.album.images[0]?.url || null,
    category: 'focus',
  };
}