import React from "react";
import { Deadline } from "@shared/schema";

interface DeadlinesProps {
  deadlines?: Deadline[];
}

const Deadlines: React.FC<DeadlinesProps> = ({ deadlines = [] }) => {
  const getUrgencyColor = (daysLeft: number) => {
    if (daysLeft <= 2) return "red";
    if (daysLeft <= 7) return "orange";
    return "blue";
  };

  return (
    <div className="glass-card rounded-xl p-5">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-semibold font-poppins">Upcoming Deadlines</h2>
        <button className="text-sm text-primary-600 dark:text-primary-400 font-medium hover:underline">
          View All
        </button>
      </div>
      
      {deadlines.length > 0 ? (
        deadlines.map((deadline) => {
          const color = getUrgencyColor(deadline.daysLeft);
          
          return (
            <div key={deadline.id} className="glass p-3 rounded-lg mb-3 relative overflow-hidden">
              <div className={`absolute top-0 left-0 w-1 h-full bg-${color}-500`}></div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-medium">{deadline.title}</h3>
                <div className={`text-xs px-2 py-0.5 bg-${color}-100 dark:bg-${color}-900/30 text-${color}-600 dark:text-${color}-400 rounded-full`}>
                  {deadline.daysLeft} days left
                </div>
              </div>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                <i className="ri-calendar-event-line mr-1"></i>
                <span>Due {deadline.dueDate}</span>
              </div>
              <div className="mt-2">
                <div className="flex justify-between text-xs mb-1">
                  <span>Progress</span>
                  <span>{deadline.progress}%</span>
                </div>
                <div className="h-1.5 w-full bg-gray-200 dark:bg-dark-700 rounded-full overflow-hidden">
                  <div 
                    className={`h-full bg-${color}-500 rounded-full`} 
                    style={{ width: `${deadline.progress}%` }}
                  ></div>
                </div>
              </div>
            </div>
          );
        })
      ) : (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          No upcoming deadlines
        </div>
      )}
    </div>
  );
};

export default Deadlines;
