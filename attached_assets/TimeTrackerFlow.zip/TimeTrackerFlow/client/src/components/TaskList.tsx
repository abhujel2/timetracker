import React, { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Task, insertTaskSchema } from "@shared/schema";
import { DialogTrigger, DialogTitle, DialogDescription, DialogContent, Dialog } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface TaskListProps {
  tasks?: {
    todo: Task[];
    inProgress: Task[];
    completed: Task[];
  };
}

const taskFormSchema = insertTaskSchema.extend({
  status: z.string(),
  project: z.string(),
  duration: z.string(),
  dueDate: z.string(),
  tags: z.string(),
});

type TaskFormValues = z.infer<typeof taskFormSchema>;

const TaskList: React.FC<TaskListProps> = ({ tasks = { todo: [], inProgress: [], completed: [] } }) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewMode, setViewMode] = useState<"board" | "list" | "calendar">("board");

  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      name: "",
      description: "",
      status: "todo",
      project: "",
      duration: "",
      dueDate: "",
      tags: "",
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: async (newTask: TaskFormValues) => {
      return apiRequest("POST", "/api/tasks", newTask);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setDialogOpen(false);
      form.reset();
    },
  });

  const updateTaskStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      return apiRequest("PATCH", `/api/tasks/${id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  const handleTaskStatusChange = (taskId: number, checked: boolean) => {
    const newStatus = checked ? "completed" : "todo";
    updateTaskStatus.mutate({ id: taskId, status: newStatus });
  };

  const handleTaskInProgress = (taskId: number) => {
    updateTaskStatus.mutate({ id: taskId, status: "inProgress" });
  };

  const onSubmit = (data: TaskFormValues) => {
    createTaskMutation.mutate(data);
  };

  return (
    <div className="glass-card rounded-xl p-5">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold font-poppins">Today's Tasks</h2>
        <div className="flex items-center">
          <button 
            onClick={() => setViewMode("list")}
            className={`p-1.5 rounded-md ${
              viewMode === "list" 
                ? "text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30" 
                : "text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-dark-700"
            } mr-2`} 
            aria-label="List view"
          >
            <i className="ri-list-check text-lg"></i>
          </button>
          <button 
            onClick={() => setViewMode("board")}
            className={`p-1.5 rounded-md ${
              viewMode === "board" 
                ? "text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30" 
                : "text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-dark-700"
            } mr-2`} 
            aria-label="Board view"
          >
            <i className="ri-layout-grid-line text-lg"></i>
          </button>
          <button 
            onClick={() => setViewMode("calendar")}
            className={`p-1.5 rounded-md ${
              viewMode === "calendar" 
                ? "text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30" 
                : "text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-dark-700"
            }`} 
            aria-label="Calendar view"
          >
            <i className="ri-calendar-line text-lg"></i>
          </button>
          <div className="h-6 w-px bg-gray-300 dark:bg-dark-600 mx-2"></div>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <button className="flex items-center px-3 py-1.5 rounded-lg bg-primary-600 hover:bg-primary-700 text-white text-sm">
                <i className="ri-add-line mr-1"></i>
                <span>Add Task</span>
              </button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogTitle>Add New Task</DialogTitle>
              <DialogDescription>
                Create a new task to track your work. Fill in the details below.
              </DialogDescription>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Task Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter task name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Task description" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="project"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Project</FormLabel>
                          <FormControl>
                            <Input placeholder="Project name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="duration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Duration</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. 1h 30m" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select 
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="todo">To Do</SelectItem>
                              <SelectItem value="inProgress">In Progress</SelectItem>
                              <SelectItem value="completed">Completed</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Due Date</FormLabel>
                          <FormControl>
                            <Input type="datetime-local" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="tags"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tags</FormLabel>
                        <FormControl>
                          <Input placeholder="Comma separated tags" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end space-x-2 pt-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createTaskMutation.isPending}
                    >
                      {createTaskMutation.isPending ? "Creating..." : "Create Task"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* To Do Column */}
        <div className="glass p-3 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-sm">To Do</h3>
            <span className="bg-gray-200 dark:bg-dark-700 text-gray-600 dark:text-gray-400 text-xs px-2 py-0.5 rounded-full">
              {tasks.todo.length}
            </span>
          </div>
          
          {tasks.todo.map((task) => (
            <div 
              key={task.id} 
              className="glass-card p-3 rounded-lg mb-3 border-l-4 border-l-gray-300 dark:border-l-gray-600"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start">
                  <div 
                    className="w-4 h-4 rounded-full border-2 border-gray-300 dark:border-gray-600 mt-1 cursor-pointer"
                    onClick={() => handleTaskStatusChange(task.id, true)}
                  ></div>
                  <div className="ml-3 flex-1">
                    <h4 className="text-sm font-medium">{task.name}</h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{task.description}</p>
                  </div>
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400">{task.duration}</div>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <div className="flex items-center">
                  {task.tags && task.tags.split(",").map((tag, index) => (
                    <span 
                      key={index} 
                      className="text-xs px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full mr-1"
                    >
                      {tag.trim()}
                    </span>
                  ))}
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleTaskInProgress(task.id)}
                    className="text-xs text-primary-600 hover:text-primary-700 dark:text-primary-400"
                  >
                    Start
                  </button>
                  <span className="text-xs text-gray-500 dark:text-gray-400">{task.dueDate}</span>
                </div>
              </div>
            </div>
          ))}
          
          {tasks.todo.length === 0 && (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400 text-sm">
              No tasks to do
            </div>
          )}
        </div>
        
        {/* In Progress Column */}
        <div className="glass p-3 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-sm">In Progress</h3>
            <span className="bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 text-xs px-2 py-0.5 rounded-full">
              {tasks.inProgress.length}
            </span>
          </div>
          
          {tasks.inProgress.map((task) => (
            <div 
              key={task.id} 
              className="glass-card p-3 rounded-lg mb-3 border-l-4 border-l-primary-500"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start">
                  <div 
                    className="w-4 h-4 rounded-full border-2 border-primary-500 mt-1 flex items-center justify-center cursor-pointer"
                    onClick={() => handleTaskStatusChange(task.id, true)}
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-primary-500"></div>
                  </div>
                  <div className="ml-3 flex-1">
                    <h4 className="text-sm font-medium">{task.name}</h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{task.description}</p>
                  </div>
                </div>
                <div className="text-xs text-primary-600 dark:text-primary-400 font-medium">{task.duration}</div>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <div className="flex items-center">
                  {task.tags && task.tags.split(",").map((tag, index) => (
                    <span 
                      key={index} 
                      className="text-xs px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full mr-1"
                    >
                      {tag.trim()}
                    </span>
                  ))}
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">{task.dueDate}</span>
              </div>
            </div>
          ))}
          
          {tasks.inProgress.length === 0 && (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400 text-sm">
              No tasks in progress
            </div>
          )}
        </div>
        
        {/* Completed Column */}
        <div className="glass p-3 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-sm">Completed</h3>
            <span className="bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 text-xs px-2 py-0.5 rounded-full">
              {tasks.completed.length}
            </span>
          </div>
          
          {tasks.completed.map((task) => (
            <div 
              key={task.id} 
              className="glass-card p-3 rounded-lg mb-3 border-l-4 border-l-green-500"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start">
                  <div 
                    className="w-4 h-4 rounded-full border-2 border-green-500 mt-1 flex items-center justify-center bg-green-500 cursor-pointer"
                    onClick={() => handleTaskStatusChange(task.id, false)}
                  >
                    <i className="ri-check-line text-white text-xs"></i>
                  </div>
                  <div className="ml-3 flex-1">
                    <h4 className="text-sm font-medium line-through text-gray-500 dark:text-gray-400">{task.name}</h4>
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-1 line-through">{task.description}</p>
                  </div>
                </div>
                <div className="text-xs text-green-600 dark:text-green-400">Done</div>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <div className="flex items-center">
                  {task.tags && task.tags.split(",").map((tag, index) => (
                    <span 
                      key={index} 
                      className="text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 rounded-full mr-1"
                    >
                      {tag.trim()}
                    </span>
                  ))}
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">{task.completedAt || task.dueDate}</span>
              </div>
            </div>
          ))}
          
          {tasks.completed.length === 0 && (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400 text-sm">
              No completed tasks
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TaskList;
