import React from "react";
import { Event } from "@shared/schema";

interface TimelineProps {
  events?: Event[];
}

const Timeline: React.FC<TimelineProps> = ({ events = [] }) => {
  const getEventIconClass = (category: string) => {
    switch (category) {
      case "meeting":
        return "bg-primary-100 dark:bg-primary-900/30";
      case "focus":
        return "bg-blue-100 dark:bg-blue-900/30";
      case "client":
        return "bg-green-100 dark:bg-green-900/30";
      case "planning":
        return "bg-orange-100 dark:bg-orange-900/30";
      default:
        return "bg-gray-100 dark:bg-gray-800";
    }
  };

  const getEventDotClass = (category: string) => {
    switch (category) {
      case "meeting":
        return "bg-primary-600";
      case "focus":
        return "bg-blue-600";
      case "client":
        return "bg-green-600";
      case "planning":
        return "bg-orange-600";
      default:
        return "bg-gray-600";
    }
  };

  const getEventIcon = (category: string) => {
    switch (category) {
      case "meeting":
        return "ri-video-chat-line";
      case "focus":
        return "ri-focus-3-line";
      case "client":
        return "ri-group-line";
      case "planning":
        return "ri-calendar-check-line";
      default:
        return "ri-calendar-event-line";
    }
  };

  return (
    <div className="glass-card rounded-xl p-5">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold font-poppins">Today's Schedule</h2>
        <button className="text-sm text-primary-600 dark:text-primary-400 font-medium hover:underline">
          View Calendar
        </button>
      </div>
      
      <div className="relative pl-8 before:content-[''] before:absolute before:left-3 before:top-0 before:bottom-0 before:w-px before:bg-gray-200 dark:before:bg-dark-700">
        {events.length > 0 ? (
          events.map((event, index) => (
            <div key={event.id} className="timeline-item mb-6 relative">
              <div className={`absolute left-[-22px] top-1 w-6 h-6 rounded-full ${getEventIconClass(event.category)} flex items-center justify-center`}>
                <div className={`w-2 h-2 rounded-full ${getEventDotClass(event.category)}`}></div>
              </div>
              <div className="glass-card p-4 rounded-lg">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                  <h3 className="font-medium text-base">{event.title}</h3>
                  <div className="flex items-center mt-1 md:mt-0">
                    <i className="ri-time-line text-gray-500 dark:text-gray-400 mr-1"></i>
                    <span className="text-sm text-gray-500 dark:text-gray-400">{event.timeRange}</span>
                  </div>
                </div>
                <div className="flex items-center text-sm">
                  <i className={`${getEventIcon(event.category)} text-gray-500 dark:text-gray-400 mr-1`}></i>
                  <span className="text-gray-500 dark:text-gray-400">{event.description}</span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            No events scheduled for today
          </div>
        )}
      </div>
    </div>
  );
};

export default Timeline;
