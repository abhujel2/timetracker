import React, { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { User, Task, Event, Stats } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Send, Brain, Lightbulb, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AIAssistantProps {
  className?: string;
}

interface AIResponse {
  message?: string;
  tasks?: {
    name: string;
    description: string;
    priority: "high" | "medium" | "low";
    estimatedDuration: string;
    category: string;
    suggestedTimeSlot?: string;
  }[];
  insights?: {
    title: string;
    description: string;
    actionItem?: string;
  }[];
  schedule?: any[];
}

const AIAssistant: React.FC<AIAssistantProps> = ({ className }) => {
  const [query, setQuery] = useState("");
  const [response, setResponse] = useState<AIResponse | null>(null);
  const [mode, setMode] = useState<"assistant" | "recommendations" | "insights">("assistant");
  const { toast } = useToast();

  const { mutate: sendQuery, isPending } = useMutation<
    AIResponse,
    Error,
    { request: string }
  >({
    mutationFn: async (payload) => {
      return await apiRequest({
        url: "/api/ai/query",
        method: "POST",
        body: payload,
      }) as AIResponse;
    },
    onSuccess: (data) => {
      setResponse(data);
      toast({
        title: "Assistant response received",
        description: "The AI assistant has processed your request.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to get assistant response: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  type RecommendationsResponse = { recommendations: AIResponse["tasks"] };
  
  const { mutate: getRecommendations, isPending: isRecommending } = useMutation<
    RecommendationsResponse,
    Error,
    void
  >({
    mutationFn: async () => {
      return await apiRequest({
        url: "/api/ai/recommendations",
        method: "POST",
        body: {
          preferences: {
            focusTime: "mornings",
            taskTypes: ["creative", "administrative", "technical"],
            workStyle: "pomodoro",
          },
        },
      }) as RecommendationsResponse;
    },
    onSuccess: (data) => {
      setResponse({ tasks: data.recommendations });
      toast({
        title: "Recommendations generated",
        description: "AI has suggested some tasks for you.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to get recommendations: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  type InsightsResponse = { insights: AIResponse["insights"], timeframe: string };
  
  const { mutate: getInsights, isPending: isAnalyzing } = useMutation<
    InsightsResponse,
    Error,
    void
  >({
    mutationFn: async () => {
      return await apiRequest({
        url: "/api/ai/insights",
        method: "POST",
        body: {
          timeframe: "last 7 days",
        },
      }) as InsightsResponse;
    },
    onSuccess: (data) => {
      setResponse({ insights: data.insights });
      toast({
        title: "Productivity insights generated",
        description: `Analysis for ${data.timeframe} complete.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to get insights: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    sendQuery({ request: query });
  };

  const handleModeChange = (newMode: typeof mode) => {
    setMode(newMode);
    setResponse(null);
    
    if (newMode === "recommendations") {
      getRecommendations();
    } else if (newMode === "insights") {
      getInsights();
    }
  };

  return (
    <Card className={`overflow-hidden ${className}`}>
      <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>AI Productivity Assistant</CardTitle>
            <CardDescription className="text-blue-100">Powered by GPT-4o</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant={mode === "assistant" ? "secondary" : "ghost"} 
              className={mode === "assistant" ? "bg-white text-blue-600" : "text-blue-100 hover:text-white hover:bg-blue-500"}
              onClick={() => handleModeChange("assistant")}
            >
              <Brain className="w-4 h-4 mr-1" />
              Assistant
            </Button>
            <Button 
              size="sm" 
              variant={mode === "recommendations" ? "secondary" : "ghost"}
              className={mode === "recommendations" ? "bg-white text-blue-600" : "text-blue-100 hover:text-white hover:bg-blue-500"}
              onClick={() => handleModeChange("recommendations")}
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              Tasks
            </Button>
            <Button 
              size="sm" 
              variant={mode === "insights" ? "secondary" : "ghost"}
              className={mode === "insights" ? "bg-white text-blue-600" : "text-blue-100 hover:text-white hover:bg-blue-500"}
              onClick={() => handleModeChange("insights")}
            >
              <Lightbulb className="w-4 h-4 mr-1" />
              Insights
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {mode === "assistant" && (
          <div className="space-y-4">
            <div className="min-h-[200px] max-h-[400px] overflow-y-auto">
              {response?.message && (
                <div className="p-4 bg-blue-50 dark:bg-slate-800 rounded-lg">
                  {response.message}
                </div>
              )}
              
              {response?.tasks && response.tasks.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Suggested Tasks</h4>
                  <ul className="space-y-2">
                    {response.tasks.map((task, i) => (
                      <li key={i} className="p-3 bg-gray-50 dark:bg-slate-800 rounded-md">
                        <div className="flex justify-between items-start">
                          <h5 className="font-medium">{task.name}</h5>
                          <Badge variant={
                            task.priority === "high" ? "destructive" : 
                            task.priority === "medium" ? "default" : 
                            "secondary"
                          }>
                            {task.priority}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{task.description}</p>
                        <div className="flex items-center gap-2 mt-2 text-xs text-gray-500 dark:text-gray-400">
                          <span>{task.category}</span>
                          <span>•</span>
                          <span>{task.estimatedDuration}</span>
                          {task.suggestedTimeSlot && (
                            <>
                              <span>•</span>
                              <span>Best time: {task.suggestedTimeSlot}</span>
                            </>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {response?.insights && response.insights.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Productivity Insights</h4>
                  <ul className="space-y-4">
                    {response.insights.map((insight, i) => (
                      <li key={i} className="p-3 bg-gray-50 dark:bg-slate-800 rounded-md">
                        <h5 className="font-medium flex items-center">
                          <Lightbulb className="w-4 h-4 mr-2 text-yellow-500" />
                          {insight.title}
                        </h5>
                        <p className="text-sm mt-1">{insight.description}</p>
                        {insight.actionItem && (
                          <div className="mt-2 text-sm font-medium text-blue-600 dark:text-blue-400">
                            Try this: {insight.actionItem}
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {!response && !isPending && !isRecommending && !isAnalyzing && mode === "assistant" && (
                <div className="flex items-center justify-center h-[200px] text-gray-400">
                  <div className="text-center">
                    <Brain className="w-12 h-12 mx-auto mb-2 opacity-30" />
                    <p>Ask me anything about your productivity</p>
                  </div>
                </div>
              )}
              
              {(isPending || isRecommending || isAnalyzing) && (
                <div className="flex items-center justify-center h-[200px]">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-700 mx-auto mb-4"></div>
                    <p className="text-gray-500">
                      {isPending ? "Processing your request..." : 
                       isRecommending ? "Generating task recommendations..." :
                       "Analyzing productivity patterns..."}
                    </p>
                  </div>
                </div>
              )}
            </div>
            
            <Separator />
            
            <form onSubmit={handleSubmit} className="flex space-x-2">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask for advice, schedule optimization, or task recommendations..."
                className="flex-grow"
                disabled={isPending}
              />
              <Button type="submit" disabled={isPending || !query.trim()}>
                <Send className="w-4 h-4 mr-2" />
                Send
              </Button>
            </form>
          </div>
        )}
        
        {mode === "recommendations" && (
          <div>
            {response?.tasks && response.tasks.length > 0 ? (
              <div>
                <h4 className="font-medium mb-3">Recommended Tasks Based on Your Activity</h4>
                <ul className="space-y-3">
                  {response.tasks.map((task, i) => (
                    <li key={i} className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-gray-700">
                      <div className="flex justify-between items-start">
                        <h5 className="font-medium">{task.name}</h5>
                        <Badge variant={
                          task.priority === "high" ? "destructive" : 
                          task.priority === "medium" ? "default" : 
                          "secondary"
                        }>
                          {task.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{task.description}</p>
                      <div className="flex items-center gap-2 mt-3 text-xs text-gray-500 dark:text-gray-400">
                        <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded">{task.category}</span>
                        <span>{task.estimatedDuration}</span>
                        {task.suggestedTimeSlot && (
                          <span className="ml-auto text-blue-600 dark:text-blue-400">
                            Best time: {task.suggestedTimeSlot}
                          </span>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <div className="flex items-center justify-center h-[300px]">
                {isRecommending ? (
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-700 mx-auto mb-4"></div>
                    <p className="text-gray-500">Generating smart task recommendations...</p>
                  </div>
                ) : (
                  <Button onClick={() => getRecommendations()}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Generate Recommendations
                  </Button>
                )}
              </div>
            )}
          </div>
        )}
        
        {mode === "insights" && (
          <div>
            {response?.insights && response.insights.length > 0 ? (
              <div>
                <h4 className="font-medium mb-3">Productivity Insights & Analysis</h4>
                <ul className="space-y-4">
                  {response.insights.map((insight, i) => (
                    <li key={i} className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-gray-700">
                      <h5 className="font-medium flex items-center">
                        <Lightbulb className="w-4 h-4 mr-2 text-yellow-500" />
                        {insight.title}
                      </h5>
                      <p className="text-sm mt-2">{insight.description}</p>
                      {insight.actionItem && (
                        <div className="mt-3 p-2 bg-blue-50 dark:bg-blue-900/30 text-sm rounded border-l-2 border-blue-500">
                          <span className="font-medium">Try this:</span> {insight.actionItem}
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <div className="flex items-center justify-center h-[300px]">
                {isAnalyzing ? (
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-700 mx-auto mb-4"></div>
                    <p className="text-gray-500">Analyzing your productivity patterns...</p>
                  </div>
                ) : (
                  <Button onClick={() => getInsights()}>
                    <Lightbulb className="w-4 h-4 mr-2" />
                    Generate Insights
                  </Button>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="bg-gray-50 dark:bg-gray-900 px-6 py-3">
        <div className="text-xs text-gray-500 dark:text-gray-400">
          AI suggestions are based on your tasks, schedule, and productivity patterns.
        </div>
      </CardFooter>
    </Card>
  );
};

export default AIAssistant;