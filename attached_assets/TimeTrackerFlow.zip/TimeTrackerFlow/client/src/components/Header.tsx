import React, { useState } from "react";
import { User } from "@shared/schema";
import { useTheme } from "@/context/ThemeContext";
import { Sun, Moon, Bell, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  user: User | undefined;
}

const Header: React.FC<HeaderProps> = ({ user }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const { theme, toggleTheme } = useTheme();
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality
    console.log("Searching for:", searchQuery);
  };
  
  return (
    <header className="mb-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-poppins font-bold">
            Good morning, {user?.username?.split(" ")[0] || "John"}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Let's have a productive day!</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <form onSubmit={handleSearch} className="relative mr-3">
            <input 
              type="text" 
              placeholder="Search tasks, music..." 
              className="pl-9 pr-4 py-2 rounded-lg border border-gray-200 dark:border-dark-700 bg-white dark:bg-dark-800 text-sm w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-gray-400" />
          </form>
          
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="w-9 h-9 rounded-lg"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>
          
          <Button 
            variant="outline" 
            size="icon"
            className="w-9 h-9 rounded-lg relative"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
