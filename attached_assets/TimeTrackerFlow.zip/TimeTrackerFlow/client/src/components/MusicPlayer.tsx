import React, { useRef, useEffect, useState } from "react";
import { useMusicPlayer } from "@/hooks/useMusicPlayer";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, 
  Music, Search, Plus, Headphones, X, Volume2, Bell
} from "lucide-react";
import { Track } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const MusicPlayer: React.FC = () => {
  const { 
    currentTrack, 
    playlist, 
    isPlaying, 
    currentTime, 
    duration,
    searchQuery,
    setSearchQuery,
    searchResults,
    isSearching,
    focusPlaylists,
    selectedPlaylistId,
    showInNotification,
    notificationPermission,
    togglePlayPause,
    playNext,
    playPrevious,
    toggleShuffle,
    toggleRepeat,
    updateTime,
    searchMusic,
    loadPlaylist,
    addTrack,
    toggleNotification,
    requestNotificationPermission
  } = useMusicPlayer();

  const [activeTab, setActiveTab] = useState("now-playing");
  const visualizerContainerRef = useRef<HTMLDivElement>(null);
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Create and animate visualizer bars
  useEffect(() => {
    if (!visualizerContainerRef.current) return;
    
    const container = visualizerContainerRef.current;
    container.innerHTML = '';
    
    // Create 30 visualizer bars
    for (let i = 0; i < 30; i++) {
      const bar = document.createElement('div');
      bar.className = 'visualizer-bar animate-pulse-slow';
      bar.style.height = `${Math.floor(Math.random() * 24) + 4}px`;
      container.appendChild(bar);
    }
    
    // Animate the bars if music is playing
    const interval = setInterval(() => {
      if (isPlaying) {
        Array.from(container.children).forEach((bar) => {
          const randomHeight = Math.floor(Math.random() * 24) + 4;
          (bar as HTMLElement).style.height = `${randomHeight}px`;
        });
      }
    }, 100);
    
    return () => clearInterval(interval);
  }, [isPlaying]);

  // Handle search form submission
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    searchMusic(searchQuery);
  };

  // Handle track selection
  const handleTrackSelect = (track: Track) => {
    addTrack(track);
  };
  
  // Handle playlist selection
  const handlePlaylistSelect = (playlistId: string) => {
    loadPlaylist(playlistId);
  };

  return (
    <div className="glass-card rounded-xl p-5 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-40 h-40 bg-primary-400 rounded-full filter blur-3xl opacity-10 -mr-20 -mt-20"></div>
      
      <h2 className="text-lg font-semibold font-poppins mb-4 flex items-center">
        <Music className="w-5 h-5 mr-2" />
        Music Player
        <div className="ml-auto flex items-center space-x-2">
          <Button
            variant="outline"
            size="icon"
            className={`h-8 w-8 ${showInNotification ? 'text-primary-600 dark:text-primary-400' : 'text-gray-500'}`}
            onClick={toggleNotification}
            title={showInNotification ? "Notification mode active" : "Enable notification mode"}
          >
            <Bell className="h-4 w-4" />
          </Button>
          <span className="text-xs px-2 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-full">
            Spotify
          </span>
        </div>
      </h2>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="now-playing" className="text-xs">Now Playing</TabsTrigger>
          <TabsTrigger value="search" className="text-xs">Search</TabsTrigger>
          <TabsTrigger value="playlists" className="text-xs">Playlists</TabsTrigger>
        </TabsList>
        
        <TabsContent value="now-playing" className="mt-0">
          <div className="flex flex-col items-center">
            <div className="w-48 h-48 rounded-xl bg-primary-100 dark:bg-primary-900/50 shadow-lg mb-5 overflow-hidden">
              {currentTrack?.coverUrl ? (
                <img 
                  src={currentTrack.coverUrl} 
                  alt={`${currentTrack.title} cover`} 
                  className="w-full h-full object-cover" 
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-primary-600 dark:text-primary-400">
                  <Headphones className="w-12 h-12" />
                </div>
              )}
            </div>
            
            <div className="w-full text-center mb-4">
              <h3 className="font-medium text-lg">{currentTrack?.title || "Select a track"}</h3>
              <p className="text-gray-500 dark:text-gray-400 mt-1">{currentTrack?.artist || "Productivity Playlist"}</p>
            </div>
            
            <div ref={visualizerContainerRef} className="visualizer w-full mb-3">
              {/* Visualizer bars will be generated here */}
            </div>
            
            <div className="w-full px-2">
              <div className="flex items-center justify-between text-xs mb-1">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
              <div className="music-progress mb-5">
                <div 
                  className="music-progress-bar" 
                  style={{ width: `${(currentTime / duration) * 100}%` }}
                ></div>
              </div>
              
              <div className="flex items-center justify-between">
                <Button 
                  variant="ghost"
                  size="icon"
                  className={`${currentTrack?.repeat ? "text-primary-600" : "text-gray-500"}`}
                  onClick={toggleRepeat}
                >
                  <Repeat className="h-4 w-4" />
                </Button>
                
                <div className="flex items-center space-x-3">
                  <Button 
                    variant="ghost"
                    size="icon"
                    className="text-gray-500"
                    onClick={playPrevious}
                    disabled={!currentTrack}
                  >
                    <SkipBack className="h-4 w-4" />
                  </Button>
                  
                  <Button 
                    className="w-12 h-12 rounded-full"
                    onClick={togglePlayPause}
                    disabled={!currentTrack}
                  >
                    {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                  </Button>
                  
                  <Button 
                    variant="ghost"
                    size="icon"
                    className="text-gray-500"
                    onClick={playNext}
                    disabled={!currentTrack}
                  >
                    <SkipForward className="h-4 w-4" />
                  </Button>
                </div>
                
                <Button 
                  variant="ghost"
                  size="icon"
                  className={`${currentTrack?.shuffle ? "text-primary-600" : "text-gray-500"}`}
                  onClick={toggleShuffle}
                >
                  <Shuffle className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-5 border-t border-gray-200 dark:border-dark-700">
            <h4 className="text-sm font-medium mb-3">Up Next</h4>
            
            {playlist.length > 0 ? (
              playlist.slice(0, 3).map((track) => (
                <div key={track.id} className="flex items-center py-2">
                  <div className="w-10 h-10 rounded-md bg-gray-200 dark:bg-dark-700 overflow-hidden mr-3">
                    {track.coverUrl ? (
                      <img 
                        src={track.coverUrl} 
                        alt={`${track.title} thumbnail`} 
                        className="w-full h-full object-cover" 
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                        <Music className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <h5 className="text-sm font-medium">{track.title}</h5>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{track.artist}</p>
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">{formatTime(track.duration)}</div>
                </div>
              ))
            ) : (
              <div className="text-center py-3 text-gray-500 dark:text-gray-400 text-sm">
                No tracks in queue
              </div>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="search" className="mt-0">
          <form onSubmit={handleSearchSubmit} className="mb-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search for tracks on Spotify..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
              <Button 
                type="submit"
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </form>
          
          <div className="h-[300px] overflow-y-auto pr-1">
            {isSearching ? (
              <div className="flex flex-col items-center justify-center h-40">
                <div className="animate-spin w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full"></div>
                <p className="mt-2 text-sm text-gray-500">Searching Spotify...</p>
              </div>
            ) : searchResults.length > 0 ? (
              <div className="space-y-2">
                {searchResults.map((track) => (
                  <div 
                    key={track.id} 
                    className="flex items-center p-2 rounded-md border border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                    onClick={() => handleTrackSelect(track)}
                  >
                    <div className="w-10 h-10 rounded-md bg-gray-200 dark:bg-dark-700 overflow-hidden mr-3">
                      {track.coverUrl ? (
                        <img 
                          src={track.coverUrl} 
                          alt={`${track.title} thumbnail`} 
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                          <Music className="h-4 w-4" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="text-sm font-medium truncate">{track.title}</h5>
                      <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{track.artist}</p>
                    </div>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="ml-1 h-8 w-8 text-primary-600"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : searchQuery ? (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No results found for "{searchQuery}"</p>
                <p className="text-xs mt-1">Try different keywords or check your spelling</p>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>Search for your favorite music</p>
                <p className="text-xs mt-1">Find tracks to boost your productivity</p>
              </div>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="playlists" className="mt-0">
          <div className="mb-4">
            <h3 className="text-sm font-medium mb-2">Focus Playlists</h3>
            <p className="text-xs text-gray-500 mb-4">Curated playlists to enhance your productivity</p>
            
            {focusPlaylists.length > 0 ? (
              <div className="grid grid-cols-2 gap-2">
                {focusPlaylists.map((playlist) => (
                  <div 
                    key={playlist.id} 
                    className={`p-2 rounded-md border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer transition-colors ${
                      selectedPlaylistId === playlist.id ? 'ring-2 ring-primary-500 bg-primary-50 dark:bg-primary-900/20' : ''
                    }`}
                    onClick={() => handlePlaylistSelect(playlist.id)}
                  >
                    <div className="aspect-square bg-gray-200 dark:bg-gray-700 rounded-md mb-2 overflow-hidden">
                      {playlist.imageUrl ? (
                        <img 
                          src={playlist.imageUrl} 
                          alt={playlist.name} 
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                          <Music className="h-8 w-8" />
                        </div>
                      )}
                    </div>
                    <p className="text-xs font-medium truncate">{playlist.name}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-40 text-gray-500">
                {isSearching ? (
                  <>
                    <div className="animate-spin w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full"></div>
                    <p className="mt-2 text-sm">Loading playlists...</p>
                  </>
                ) : (
                  <>
                    <Music className="h-8 w-8 mb-2 opacity-50" />
                    <p className="text-sm">No playlists available</p>
                    <p className="text-xs mt-1">Try refreshing the page</p>
                  </>
                )}
              </div>
            )}
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-2">Current Playlist</h3>
            
            {isSearching ? (
              <div className="flex flex-col items-center justify-center h-40">
                <div className="animate-spin w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full"></div>
                <p className="mt-2 text-sm text-gray-500">Loading tracks...</p>
              </div>
            ) : playlist.length > 0 ? (
              <div className="max-h-[200px] overflow-y-auto space-y-1">
                {playlist.map((track, index) => (
                  <div 
                    key={`${track.id}-${index}`} 
                    className="flex items-center p-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                    onClick={() => {
                      // Set current track index
                      // setCurrentTrackIndex is not in the hook's return value, so we'll use a different approach
                      if (isPlaying) togglePlayPause(); // Pause if playing
                      // Find track index in the playlist
                      const trackIndex = playlist.findIndex(t => t.id === track.id);
                      if (trackIndex !== -1) {
                        // We can't use setCurrentTrackIndex, so we'll rely on the hook's logic
                        // Play the previous track and then the desired track
                        playPrevious();
                        for (let i = 0; i < trackIndex + 1; i++) {
                          playNext();
                        }
                      }
                    }}
                  >
                    <div className="w-8 h-8 rounded-md bg-gray-200 dark:bg-dark-700 overflow-hidden mr-2 flex-shrink-0">
                      {track.coverUrl ? (
                        <img 
                          src={track.coverUrl} 
                          alt={`${track.title} thumbnail`} 
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                          <Music className="h-3 w-3" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="text-xs font-medium truncate">{track.title}</h5>
                      <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{track.artist}</p>
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 ml-1">
                      {formatTime(track.duration)}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                <p className="text-sm">No tracks in playlist</p>
                <p className="text-xs mt-1">Select a playlist or search for tracks</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MusicPlayer;
