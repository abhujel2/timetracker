import React, { useState, useRef } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { FileText, Upload, Folder, X, Check, File, FilePlus2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface FileUploaderProps {
  className?: string;
}

type UploadStatus = "idle" | "uploading" | "success" | "error";

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  path?: string;
  status: UploadStatus;
  progress: number;
  error?: string;
}

const FileUploader: React.FC<FileUploaderProps> = ({ className }) => {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState<UploadStatus>("idle");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };
  
  const generateId = () => {
    return Math.random().toString(36).substring(2, 15) + 
      Math.random().toString(36).substring(2, 15);
  };
  
  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    
    setUploadStatus("uploading");
    
    // Convert FileList to array and track status for each file
    const newFiles = Array.from(files).map(file => ({
      id: generateId(),
      name: file.name,
      size: file.size,
      type: file.type,
      path: file.webkitRelativePath || undefined,
      status: "uploading" as UploadStatus,
      progress: 0,
    }));
    
    setUploadedFiles(prev => [...prev, ...newFiles]);
    
    // Simulate file upload progress
    const totalFiles = newFiles.length;
    let processed = 0;
    
    newFiles.forEach((fileInfo, index) => {
      // Simulate variable upload times based on file size
      const uploadTime = Math.max(500, Math.min(2000, fileInfo.size / 10000));
      
      const intervalId = setInterval(() => {
        setUploadedFiles(prev => {
          const updatedFiles = [...prev];
          const fileIndex = updatedFiles.findIndex(f => f.id === fileInfo.id);
          
          if (fileIndex !== -1) {
            const progress = Math.min(100, updatedFiles[fileIndex].progress + 10);
            updatedFiles[fileIndex] = {
              ...updatedFiles[fileIndex],
              progress,
            };
            
            if (progress === 100) {
              clearInterval(intervalId);
              updatedFiles[fileIndex].status = Math.random() > 0.9 ? "error" : "success";
              if (updatedFiles[fileIndex].status === "error") {
                updatedFiles[fileIndex].error = "Failed to upload file.";
              }
              
              processed++;
              if (processed === totalFiles) {
                setUploadStatus("success");
                toast({
                  title: "Upload complete",
                  description: `Successfully uploaded ${totalFiles - updatedFiles.filter(f => f.status === "error").length}/${totalFiles} files.`,
                });
              }
            }
          }
          
          return updatedFiles;
        });
        
        // Update overall progress
        setUploadProgress(prev => Math.min(99, prev + (100 / (totalFiles * 10))));
      }, uploadTime / 10);
    });
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    handleFileUpload(e.dataTransfer.files);
  };
  
  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };
  
  const handleSelectFolder = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.webkitdirectory = true;
    input.multiple = true;
    
    input.onchange = (e: Event) => {
      const target = e.target as HTMLInputElement;
      handleFileUpload(target.files);
    };
    
    input.click();
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFileUpload(e.target.files);
  };
  
  const removeFile = (id: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== id));
  };
  
  const retryFile = (id: string) => {
    setUploadedFiles(prev => prev.map(file => 
      file.id === id ? { ...file, status: "uploading", progress: 0, error: undefined } : file
    ));
    
    // Simulate retry
    const intervalId = setInterval(() => {
      setUploadedFiles(prev => {
        const updatedFiles = [...prev];
        const fileIndex = updatedFiles.findIndex(f => f.id === id);
        
        if (fileIndex !== -1 && updatedFiles[fileIndex].status === "uploading") {
          const progress = Math.min(100, updatedFiles[fileIndex].progress + 10);
          updatedFiles[fileIndex] = {
            ...updatedFiles[fileIndex],
            progress,
          };
          
          if (progress === 100) {
            clearInterval(intervalId);
            updatedFiles[fileIndex].status = "success";
          }
        }
        
        return updatedFiles;
      });
    }, 100);
  };
  
  const getFileIcon = (file: UploadedFile) => {
    if (file.type.includes("image")) return "🖼️";
    if (file.type.includes("pdf")) return "📄";
    if (file.type.includes("word") || file.type.includes("document")) return "📝";
    if (file.type.includes("spreadsheet") || file.type.includes("excel")) return "📊";
    if (file.type.includes("presentation") || file.type.includes("powerpoint")) return "📑";
    if (file.type.includes("audio")) return "🎵";
    if (file.type.includes("video")) return "🎬";
    if (file.type.includes("zip") || file.type.includes("rar") || file.type.includes("archive")) return "📦";
    return "📄";
  };
  
  const formatFileSize = (size: number) => {
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  };
  
  return (
    <Card className={`${className} overflow-hidden`}>
      <CardHeader className="bg-gradient-to-r from-green-600 to-teal-600 text-white">
        <CardTitle className="flex items-center gap-2">
          <FilePlus2 className="h-5 w-5" />
          File & Folder Uploader
        </CardTitle>
        <CardDescription className="text-green-100">
          Upload documents, images, and folders to your workspace
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div 
          className={`border-2 border-dashed rounded-lg p-6 mb-6 text-center transition-colors ${
            dragActive 
              ? "border-primary bg-primary/5" 
              : "border-gray-200 dark:border-gray-700 hover:border-primary/50"
          }`}
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
        >
          <div className="mb-4">
            <Upload className="h-12 w-12 mx-auto text-gray-400" />
          </div>
          <p className="mb-2 text-sm font-medium">
            Drag and drop files here or
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            <Button 
              variant="outline" 
              size="sm"
              className="flex items-center gap-1"
              onClick={handleBrowseClick}
            >
              <FileText className="h-4 w-4" />
              Browse Files
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              className="flex items-center gap-1"
              onClick={handleSelectFolder}
            >
              <Folder className="h-4 w-4" />
              Select Folder
            </Button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={handleFileChange}
          />
          <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
            Supported file types: PDF, Word, Excel, PowerPoint, Images, and more
          </p>
        </div>
        
        {uploadedFiles.length > 0 && (
          <div>
            <div className="mb-2 flex justify-between items-center">
              <h3 className="text-sm font-medium">
                Uploaded Files ({uploadedFiles.length})
              </h3>
              {uploadStatus === "uploading" && (
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-blue-500 animate-pulse"></div>
                  <span className="text-xs text-gray-500">Uploading...</span>
                </div>
              )}
            </div>
            
            <div className="space-y-2 max-h-[250px] overflow-y-auto p-1">
              {uploadedFiles.map(file => (
                <div 
                  key={file.id} 
                  className="flex items-center p-2 rounded-lg border border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-900"
                >
                  <div className="mr-3 text-xl">{getFileIcon(file)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between mb-1">
                      <p className="text-sm font-medium truncate">{file.name}</p>
                      <span className="text-xs text-gray-500">{formatFileSize(file.size)}</span>
                    </div>
                    
                    {file.status === "uploading" ? (
                      <Progress value={file.progress} className="h-1.5" />
                    ) : file.status === "success" ? (
                      <div className="flex items-center text-green-600 text-xs">
                        <Check className="w-3 h-3 mr-1" />
                        Uploaded successfully
                      </div>
                    ) : (
                      <div className="flex items-center text-red-600 text-xs">
                        <X className="w-3 h-3 mr-1" />
                        {file.error || "Upload failed"}
                      </div>
                    )}
                  </div>
                  
                  <div className="ml-2 flex">
                    {file.status === "error" ? (
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-7 w-7 rounded-full"
                        onClick={() => retryFile(file.id)}
                      >
                        <Upload className="h-3.5 w-3.5 text-gray-500" />
                      </Button>
                    ) : null}
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="h-7 w-7 rounded-full"
                      onClick={() => removeFile(file.id)}
                    >
                      <X className="h-3.5 w-3.5 text-gray-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="bg-gray-50 dark:bg-gray-900 px-6 py-3">
        <div className="text-xs text-gray-500 dark:text-gray-400">
          Files will be attached to your productivity workspace. Maximum file size: 20MB.
        </div>
      </CardFooter>
    </Card>
  );
};

export default FileUploader;