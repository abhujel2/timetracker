import React from "react";
import { usePomodoro } from "@/hooks/usePomodoro";
import { Task } from "@shared/schema";

interface PomodoroTimerProps {
  currentTask?: Task;
}

const PomodoroTimer: React.FC<PomodoroTimerProps> = ({ currentTask }) => {
  const { 
    mode, 
    timeLeft, 
    isRunning, 
    progress, 
    completedPomodoros,
    totalPomodoros,
    totalFocusTime,
    toggleTimer, 
    resetTimer, 
    skipTimer,
    setMode
  } = usePomodoro();

  // Format time as MM:SS
  const formattedTime = () => {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  };

  // Format focus time as HH:MM:SS
  const formatFocusTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="glass-card rounded-xl p-5">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
        <h2 className="text-lg font-semibold font-poppins">Current Focus</h2>
        <div className="flex items-center space-x-2 mt-2 md:mt-0">
          <button 
            className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
              mode === "pomodoro" 
                ? "bg-primary-50 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400" 
                : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700"
            }`}
            onClick={() => setMode("pomodoro")}
          >
            Pomodoro
          </button>
          <button 
            className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
              mode === "shortBreak" 
                ? "bg-primary-50 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400" 
                : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700"
            }`}
            onClick={() => setMode("shortBreak")}
          >
            Short Break
          </button>
          <button 
            className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
              mode === "longBreak" 
                ? "bg-primary-50 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400" 
                : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700"
            }`}
            onClick={() => setMode("longBreak")}
          >
            Long Break
          </button>
        </div>
      </div>
      
      <div className="flex flex-col items-center justify-center md:flex-row md:justify-between">
        <div className="flex flex-col items-center mb-6 md:mb-0">
          <div className="relative">
            <div className="w-40 h-40 rounded-full bg-primary-50 dark:bg-dark-700 flex items-center justify-center text-4xl font-bold text-primary-600 dark:text-primary-400">
              {formattedTime()}
            </div>
            <svg className="absolute top-0 left-0 w-40 h-40" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(140, 111, 255, 0.2)" strokeWidth="4" />
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                fill="none" 
                stroke="#8C6FFF" 
                strokeWidth="4" 
                strokeDasharray="283" 
                strokeDashoffset={283 - (283 * progress / 100)} 
                transform="rotate(-90 50 50)" 
              />
            </svg>
          </div>
          <div className="mt-4 flex space-x-3">
            <button 
              className="p-2 rounded-full bg-primary-600 text-white shadow-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
              onClick={toggleTimer}
            >
              <i className={`${isRunning ? "ri-pause-fill" : "ri-play-fill"} text-xl`}></i>
            </button>
            <button 
              className="p-2 rounded-full bg-gray-200 dark:bg-dark-700 text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-dark-600 focus:outline-none"
              onClick={resetTimer}
            >
              <i className="ri-restart-line text-xl"></i>
            </button>
            <button 
              className="p-2 rounded-full bg-gray-200 dark:bg-dark-700 text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-dark-600 focus:outline-none"
              onClick={skipTimer}
            >
              <i className="ri-skip-forward-fill text-xl"></i>
            </button>
          </div>
        </div>
        
        <div className="w-full md:w-1/2">
          <div className="glass p-4 rounded-lg mb-4">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-medium">{currentTask?.name || "Website Redesign"}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{currentTask?.project || "Client Project"}</p>
              </div>
              <span className="text-xs px-2 py-0.5 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full">
                In Progress
              </span>
            </div>
            
            <div className="mt-3">
              <div className="flex justify-between text-xs mb-1">
                <span>Progress</span>
                <span>{currentTask?.progress || 65}%</span>
              </div>
              <div className="h-1.5 w-full bg-gray-200 dark:bg-dark-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-500 rounded-full" 
                  style={{ width: `${currentTask?.progress || 65}%` }}
                ></div>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-2">Session Stats</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="glass p-3 rounded-lg">
                <div className="text-sm text-gray-500 dark:text-gray-400">Completed</div>
                <div className="text-xl font-semibold">{completedPomodoros} / {totalPomodoros}</div>
              </div>
              <div className="glass p-3 rounded-lg">
                <div className="text-sm text-gray-500 dark:text-gray-400">Focus Time</div>
                <div className="text-xl font-semibold">{formatFocusTime(totalFocusTime)}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PomodoroTimer;
