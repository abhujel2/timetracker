import React from "react";
import { Stats } from "@shared/schema";

interface ProductivityStatsProps {
  stats?: Stats;
}

const ProductivityStats: React.FC<ProductivityStatsProps> = ({ stats }) => {
  const timeDistributionData = stats?.timeDistribution || [
    { category: "Design", percentage: 45, color: "primary-500" },
    { category: "Development", percentage: 25, color: "secondary-400" },
    { category: "Meetings", percentage: 20, color: "accent-400" },
    { category: "Other", percentage: 10, color: "gray-400" },
  ];

  const weeklyData = stats?.weeklyData || [
    { day: "Mon", totalHours: 3, productiveHours: 1.5 },
    { day: "Tue", totalHours: 8, productiveHours: 6 },
    { day: "Wed", totalHours: 11, productiveHours: 9.9 },
    { day: "Thu", totalHours: 7, productiveHours: 4.2 },
    { day: "Fri", totalHours: 9, productiveHours: 7.2 },
    { day: "Sat", totalHours: 5, productiveHours: 2 },
    { day: "Sun", totalHours: 2.5, productiveHours: 0.5 },
  ];

  // Calculate the clip path for each segment of the pie chart
  const calculatePieSegments = () => {
    let runningPercentage = 0;
    return timeDistributionData.map((item) => {
      const startPercentage = runningPercentage;
      const endPercentage = startPercentage + item.percentage;
      runningPercentage = endPercentage;
      
      return {
        ...item,
        clipPath: `polygon(0 0, 100% 0, 100% ${endPercentage}%, 0 ${endPercentage}%, 0 ${startPercentage}%, 100% ${startPercentage}%)`,
      };
    });
  };

  const pieSegments = calculatePieSegments();

  // Find the tallest bar for scaling
  const maxHours = Math.max(...weeklyData.map(d => d.totalHours));
  const scaleHeight = (hours: number) => (hours / maxHours) * 110;

  return (
    <div className="glass-card rounded-xl p-5">
      <h2 className="text-lg font-semibold font-poppins mb-5">Productivity Stats</h2>
      
      <div className="mb-6">
        <h3 className="text-sm font-medium mb-3">Time Distribution</h3>
        <div className="relative h-44">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-32 h-32 rounded-full border-8 border-gray-200 dark:border-dark-700 relative">
              {pieSegments.map((segment, index) => (
                <div 
                  key={index}
                  className={`absolute inset-0 border-8 border-${segment.color} rounded-full`} 
                  style={{ clipPath: segment.clipPath }}
                ></div>
              ))}
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0">
            <div className="flex flex-wrap justify-around text-xs text-gray-500 dark:text-gray-400">
              {timeDistributionData.map((item, index) => (
                <div key={index} className="flex items-center mb-1">
                  <div className={`w-3 h-3 rounded-full bg-${item.color} mr-1`}></div>
                  <span>{item.category} ({item.percentage}%)</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="text-sm font-medium mb-3">Weekly Overview</h3>
        <div className="h-40 flex items-end justify-between">
          {weeklyData.map((day, index) => (
            <div key={index} className="flex flex-col items-center">
              <div 
                className="w-6 bg-primary-100 dark:bg-primary-900/30 rounded-t-md relative" 
                style={{ height: `${scaleHeight(day.totalHours)}px` }}
              >
                <div 
                  className="absolute bottom-0 left-0 right-0 bg-primary-500 rounded-t-md" 
                  style={{ height: `${(day.productiveHours / day.totalHours) * 100}%` }}
                ></div>
              </div>
              <div className="text-xs mt-1 text-gray-500 dark:text-gray-400">{day.day}</div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-6 pt-5 border-t border-gray-200 dark:border-dark-700">
        <div className="grid grid-cols-2 gap-4">
          <div className="glass p-3 rounded-lg">
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Focus Score</div>
            <div className="text-xl font-semibold flex items-center">
              <span>{stats?.focusScore || 87}</span>
              <span className="text-xs text-green-500 ml-1">{stats?.focusScoreChange || "+5%"}</span>
            </div>
          </div>
          
          <div className="glass p-3 rounded-lg">
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Tasks Completed</div>
            <div className="text-xl font-semibold flex items-center">
              <span>{stats?.tasksCompleted || "23/28"}</span>
              <span className="text-xs text-green-500 ml-1">{stats?.taskCompletionRate || "82%"}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductivityStats;
