import React from "react";
import { useLocation, Link } from "wouter";
import { useTheme } from "@/context/ThemeContext";
import { User } from "@shared/schema";

interface SidebarProps {
  user: User | undefined;
}

const Sidebar: React.FC<SidebarProps> = ({ user }) => {
  const [location] = useLocation();
  const { isDarkMode, toggleTheme } = useTheme();

  const navItems = [
    { icon: "ri-dashboard-line", text: "Dashboard", path: "/" },
    { icon: "ri-calendar-2-line", text: "Schedule", path: "/schedule" },
    { icon: "ri-time-line", text: "Time Tracking", path: "/time-tracking" },
    { icon: "ri-task-line", text: "Tasks", path: "/tasks" },
    { icon: "ri-music-2-line", text: "Music Player", path: "/music" },
    { icon: "ri-line-chart-line", text: "Analytics", path: "/analytics" },
  ];

  return (
    <aside className="glass lg:w-64 w-full lg:h-screen overflow-y-auto p-4 flex flex-col z-10">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-xl font-poppins font-bold text-primary-600 flex items-center">
          <i className="ri-focus-3-line mr-2"></i>
          <span>Focus Flow</span>
        </h1>
        
        <button 
          id="themeToggle" 
          onClick={toggleTheme}
          className="w-12 h-6 rounded-full bg-gray-300 dark:bg-dark-700 flex items-center transition duration-300 focus:outline-none shadow"
        >
          <div 
            className={`toggle-circle bg-white dark:bg-primary-600 w-5 h-5 rounded-full shadow-md transform transition-transform ${
              isDarkMode ? "translate-x-6" : "translate-x-0"
            } mx-0.5`}
          ></div>
        </button>
      </div>
      
      <div className="mb-6">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600">
            <span className="font-semibold text-sm">
              {user ? user.username.substring(0, 2).toUpperCase() : "JD"}
            </span>
          </div>
          <div className="ml-3">
            <h3 className="font-medium text-sm">{user?.username || "John Doe"}</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">{user?.title || "Product Designer"}</p>
          </div>
        </div>
      </div>
      
      <nav className="space-y-1 mb-6">
        {navItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={`flex items-center px-3 py-2.5 text-sm rounded-lg font-medium ${
              location === item.path 
                ? "bg-primary-50 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400" 
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700"
            }`}
          >
            <i className={`${item.icon} mr-3 text-lg`}></i>
            <span>{item.text}</span>
          </Link>
        ))}
      </nav>
      
      <div className="mt-auto">
        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium">Focused Time</h3>
            <span className="text-xs px-2 py-0.5 bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 rounded-full">Today</span>
          </div>
          
          <div className="flex items-center mb-1">
            <div className="text-2xl font-semibold">4h 26m</div>
            <div className="ml-2 text-xs text-green-500 flex items-center">
              <i className="ri-arrow-up-s-line"></i>
              <span>18%</span>
            </div>
          </div>
          
          <div className="h-1.5 w-full bg-gray-200 dark:bg-dark-700 rounded-full overflow-hidden">
            <div className="h-full bg-primary-600 rounded-full" style={{ width: "68%" }}></div>
          </div>
          
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            6h 30m goal
          </div>
        </div>
        
        <div className="mt-4 p-2">
          <Link 
            href="/settings" 
            className="flex items-center text-sm text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400"
          >
            <i className="ri-settings-3-line mr-2"></i>
            <span>Settings</span>
          </Link>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
