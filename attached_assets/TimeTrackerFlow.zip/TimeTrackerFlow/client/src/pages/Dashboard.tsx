import React from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import PomodoroTimer from "@/components/PomodoroTimer";
import TaskList from "@/components/TaskList";
import Timeline from "@/components/Timeline";
import MusicPlayer from "@/components/MusicPlayer";
import ProductivityStats from "@/components/ProductivityStats";
import Deadlines from "@/components/Deadlines";
import AIAssistant from "@/components/AIAssistant";
import FileUploader from "@/components/FileUploader";

const Dashboard: React.FC = () => {
  const { data: userData } = useQuery({
    queryKey: ["/api/user"],
  });

  const { data: taskData } = useQuery({
    queryKey: ["/api/tasks"],
  });

  const { data: scheduleData } = useQuery({
    queryKey: ["/api/schedule"],
  });

  const { data: statsData } = useQuery({
    queryKey: ["/api/stats"],
  });

  const { data: deadlinesData } = useQuery({
    queryKey: ["/api/deadlines"],
  });

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-gray-50 text-dark-800 dark:bg-dark-900 dark:text-gray-100 font-sans">
      <Sidebar user={userData} />
      
      <main className="flex-1 p-4 lg:p-6 overflow-y-auto">
        <Header user={userData} />
        
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="space-y-6 col-span-1 xl:col-span-2">
            <PomodoroTimer currentTask={taskData?.currentTask} />
            <TaskList tasks={taskData?.tasks} />
            <AIAssistant className="mb-6" />
            <Timeline events={scheduleData?.events} />
          </div>
          
          <div className="space-y-6">
            <MusicPlayer />
            <FileUploader />
            <ProductivityStats stats={statsData} />
            <Deadlines deadlines={deadlinesData?.deadlines} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
