import { useState, useEffect, useCallback, useRef } from "react";
import { useToast } from "@/hooks/use-toast";

type PomodoroMode = "pomodoro" | "shortBreak" | "longBreak";

interface PomodoroSettings {
  pomodoro: number;
  shortBreak: number;
  longBreak: number;
  longBreakInterval: number;
}

export const usePomodoro = () => {
  const { toast } = useToast();
  
  // Default settings (in seconds)
  const defaultSettings: PomodoroSettings = {
    pomodoro: 25 * 60,
    shortBreak: 5 * 60,
    longBreak: 15 * 60,
    longBreakInterval: 4,
  };
  
  const [settings] = useState<PomodoroSettings>(defaultSettings);
  const [mode, setMode] = useState<PomodoroMode>("pomodoro");
  const [timeLeft, setTimeLeft] = useState(settings.pomodoro);
  const [isRunning, setIsRunning] = useState(false);
  const [completedPomodoros, setCompletedPomodoros] = useState(0);
  const [totalPomodoros, setTotalPomodoros] = useState(4);
  const [totalFocusTime, setTotalFocusTime] = useState(0);
  
  const timerRef = useRef<number | null>(null);
  const focusTimeRef = useRef<number | null>(null);
  
  // Calculate progress percentage
  const calculateProgress = useCallback(() => {
    const totalTime = settings[mode];
    return Math.round(((totalTime - timeLeft) / totalTime) * 100);
  }, [timeLeft, mode, settings]);
  
  const progress = calculateProgress();
  
  // Handle timer completion
  const handleTimerComplete = useCallback(() => {
    const audio = new Audio("/notification.mp3");
    audio.play().catch(() => {
      // Handle browser autoplay restrictions
      console.log("Audio autoplay blocked - user interaction required");
    });
    
    if (mode === "pomodoro") {
      const newCompletedPomodoros = completedPomodoros + 1;
      setCompletedPomodoros(newCompletedPomodoros);
      
      if (newCompletedPomodoros % settings.longBreakInterval === 0) {
        toast({
          title: "Time for a long break!",
          description: "Great work! Take a longer break to recharge.",
        });
        setMode("longBreak");
        setTimeLeft(settings.longBreak);
      } else {
        toast({
          title: "Time for a short break!",
          description: "Good job! Take a quick break.",
        });
        setMode("shortBreak");
        setTimeLeft(settings.shortBreak);
      }
    } else {
      toast({
        title: "Break time is over!",
        description: "Let's get back to work.",
      });
      setMode("pomodoro");
      setTimeLeft(settings.pomodoro);
    }
    
    setIsRunning(false);
  }, [mode, completedPomodoros, settings, toast]);
  
  // Toggle timer between running and paused
  const toggleTimer = useCallback(() => {
    setIsRunning(prev => !prev);
  }, []);
  
  // Reset timer to initial state based on current mode
  const resetTimer = useCallback(() => {
    setTimeLeft(settings[mode]);
    setIsRunning(false);
  }, [mode, settings]);
  
  // Skip to next timer
  const skipTimer = useCallback(() => {
    if (mode === "pomodoro") {
      if ((completedPomodoros + 1) % settings.longBreakInterval === 0) {
        setMode("longBreak");
        setTimeLeft(settings.longBreak);
      } else {
        setMode("shortBreak");
        setTimeLeft(settings.shortBreak);
      }
    } else {
      setMode("pomodoro");
      setTimeLeft(settings.pomodoro);
    }
    setIsRunning(false);
  }, [mode, completedPomodoros, settings]);
  
  // Handle mode change
  useEffect(() => {
    setTimeLeft(settings[mode]);
    setIsRunning(false);
  }, [mode, settings]);
  
  // Countdown timer
  useEffect(() => {
    if (isRunning) {
      timerRef.current = window.setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            handleTimerComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRunning, handleTimerComplete]);
  
  // Track total focus time
  useEffect(() => {
    if (isRunning && mode === "pomodoro") {
      focusTimeRef.current = window.setInterval(() => {
        setTotalFocusTime(prev => prev + 1);
      }, 1000);
    } else if (focusTimeRef.current) {
      clearInterval(focusTimeRef.current);
    }
    
    return () => {
      if (focusTimeRef.current) {
        clearInterval(focusTimeRef.current);
      }
    };
  }, [isRunning, mode]);
  
  return {
    mode,
    timeLeft,
    isRunning,
    progress,
    completedPomodoros,
    totalPomodoros,
    totalFocusTime,
    toggleTimer,
    resetTimer,
    skipTimer,
    setMode,
  };
};
