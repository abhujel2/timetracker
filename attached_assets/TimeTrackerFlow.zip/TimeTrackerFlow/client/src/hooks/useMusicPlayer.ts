import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { Track } from "@shared/schema";
import { searchSpotifyTracks, getSpotifyRecommendations, getFocusPlaylists, getPlaylistTracks } from "@/lib/spotify";
import { useToast } from "@/hooks/use-toast";

export const useMusicPlayer = () => {
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [spotifyTracks, setSpotifyTracks] = useState<Track[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Track[]>([]);
  const [focusPlaylists, setFocusPlaylists] = useState<{id: string, name: string, imageUrl: string}[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [showInNotification, setShowInNotification] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission | null>(null);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const intervalRef = useRef<number | null>(null);
  const notificationRef = useRef<Notification | null>(null);
  const { toast } = useToast();
  
  // Get default tracks from our backend
  const { data: tracksData } = useQuery({
    queryKey: ["/api/music/tracks"],
  });
  
  // Combine local tracks with Spotify tracks
  const internalTracks: Track[] = tracksData?.tracks || [];
  const playlist: Track[] = [...internalTracks, ...spotifyTracks];
  
  // Load productivity/focus playlists when component mounts
  useEffect(() => {
    const loadFocusPlaylists = async () => {
      try {
        const playlists = await getFocusPlaylists();
        setFocusPlaylists(playlists);
      } catch (error) {
        console.error("Error loading focus playlists:", error);
      }
    };
    
    const loadRecommendedTracks = async () => {
      try {
        // Get focus music recommendations
        const recommendedTracks = await getSpotifyRecommendations(
          undefined, 
          undefined, 
          ["focus", "study", "ambient", "instrumental"]
        );
        
        if (recommendedTracks.length > 0) {
          setSpotifyTracks(recommendedTracks);
        }
      } catch (error) {
        console.error("Error loading recommended tracks:", error);
      }
    };
    
    loadFocusPlaylists();
    loadRecommendedTracks();
  }, []);
  
  const currentTrack = currentTrackIndex !== null ? playlist[currentTrackIndex] : null;
  
  // Declare playNext first as a function reference
  // so we can use it in other functions that are defined before it
  const playNextRef = useRef<() => void>();
  
  // The actual playNext implementation (will be assigned to playNextRef later)
  const playNext = useCallback(() => {
    if (playlist.length === 0) return;
    
    if (shuffle) {
      // Play random track but not the current one
      let randomIndex = Math.floor(Math.random() * playlist.length);
      if (playlist.length > 1 && randomIndex === currentTrackIndex) {
        randomIndex = (randomIndex + 1) % playlist.length;
      }
      setCurrentTrackIndex(randomIndex);
    } else {
      // Play next track in sequence
      setCurrentTrackIndex(prev => 
        prev === null 
          ? 0 
          : (prev + 1) % playlist.length
      );
    }
    
    setIsPlaying(true);
  }, [playlist, currentTrackIndex, shuffle]);
  
  // Assign the implemented function to the ref
  useEffect(() => {
    playNextRef.current = playNext;
  }, [playNext]);
  
  // Check notification permission on component mount
  useEffect(() => {
    // Check if the browser supports notifications
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  // Request notification permission
  const requestNotificationPermission = useCallback(async () => {
    if (!('Notification' in window)) {
      toast({
        title: "Notifications not supported",
        description: "Your browser doesn't support notifications",
        variant: "destructive"
      });
      return false;
    }

    if (Notification.permission === 'granted') {
      setNotificationPermission('granted');
      return true;
    }

    try {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      return permission === 'granted';
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return false;
    }
  }, [toast]);

  // Toggle notification visibility
  const toggleNotification = useCallback(async () => {
    const newState = !showInNotification;
    
    if (newState && notificationPermission !== 'granted') {
      const granted = await requestNotificationPermission();
      if (!granted) return;
    }
    
    setShowInNotification(newState);
    
    if (newState) {
      toast({
        title: "Notification mode enabled",
        description: "Music player will stay visible when you close the app",
      });
    } else {
      if (notificationRef.current) {
        notificationRef.current.close();
        notificationRef.current = null;
      }
      
      toast({
        title: "Notification mode disabled",
        description: "Music player will no longer show in notifications",
      });
    }
  }, [showInNotification, notificationPermission, requestNotificationPermission, toast]);

  // Update notification when current track changes
  useEffect(() => {
    if (showInNotification && notificationPermission === 'granted' && currentTrack) {
      // Close previous notification if it exists
      if (notificationRef.current) {
        notificationRef.current.close();
      }
      
      // Create new notification
      const notification = new Notification("Now Playing", {
        body: `${currentTrack.title} - ${currentTrack.artist}`,
        icon: currentTrack.coverUrl || '/music-icon.png',
        silent: true, // Don't play notification sound
        tag: 'music-player', // Replace existing notifications with the same tag
      });
      
      // Add notification actions
      notification.addEventListener('click', () => {
        // Focus the window when the notification is clicked
        window.focus();
      });
      
      notificationRef.current = notification;
    }
  }, [currentTrack, showInNotification, notificationPermission]);

  // Initialize audio element
  useEffect(() => {
    audioRef.current = new Audio();
    
    // Set up event listeners
    const audio = audioRef.current;
    
    const handleTimeUpdate = () => {
      if (audio) {
        setCurrentTime(audio.currentTime);
      }
    };
    
    const handleDurationChange = () => {
      if (audio) {
        setDuration(audio.duration);
      }
    };
    
    const handleEnded = () => {
      if (repeat) {
        // Replay the same track
        audio.currentTime = 0;
        audio.play().catch(err => console.error("Error replaying track:", err));
      } else {
        // Use the ref to the function
        if (playNextRef.current) {
          playNextRef.current();
        }
      }
    };
    
    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("durationchange", handleDurationChange);
    audio.addEventListener("ended", handleEnded);
    
    // Cleanup
    return () => {
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("durationchange", handleDurationChange);
      audio.removeEventListener("ended", handleEnded);
      
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      
      if (notificationRef.current) {
        notificationRef.current.close();
      }
      
      audio.pause();
      audio.src = "";
    };
  }, [repeat]);
  
  // Load track when currentTrackIndex changes
  useEffect(() => {
    if (currentTrackIndex !== null && playlist.length > 0 && audioRef.current) {
      const audio = audioRef.current;
      const track = playlist[currentTrackIndex];
      
      // Set new audio source
      audio.src = track.audioUrl;
      audio.load();
      
      // Play if isPlaying is true
      if (isPlaying) {
        audio.play().catch(err => {
          console.error("Error playing track:", err);
          setIsPlaying(false);
        });
      }
    }
  }, [currentTrackIndex, playlist, isPlaying]);
  
  // Play/pause toggle
  const togglePlayPause = useCallback(() => {
    const audio = audioRef.current;
    
    if (!audio) return;
    
    if (currentTrackIndex === null && playlist.length > 0) {
      // Start playing first track if none is selected
      setCurrentTrackIndex(0);
      setIsPlaying(true);
    } else if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().catch(err => {
        console.error("Error playing track:", err);
        setIsPlaying(false);
      });
      setIsPlaying(true);
    }
  }, [currentTrackIndex, isPlaying, playlist]);
  
// Play next track function is defined at the top of the component
  
  // Play previous track
  const playPrevious = useCallback(() => {
    if (playlist.length === 0) return;
    
    if (currentTime > 3) {
      // If more than 3 seconds into the song, restart it
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
      }
    } else {
      // Go to previous track
      setCurrentTrackIndex(prev => 
        prev === null 
          ? playlist.length - 1 
          : (prev - 1 + playlist.length) % playlist.length
      );
    }
    
    setIsPlaying(true);
  }, [playlist, currentTime]);
  
  // Toggle shuffle
  const toggleShuffle = useCallback(() => {
    setShuffle(prev => !prev);
  }, []);
  
  // Toggle repeat
  const toggleRepeat = useCallback(() => {
    setRepeat(prev => !prev);
  }, []);
  
  // Update current time (for seeking)
  const updateTime = useCallback((newTime: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  }, []);
  
  // Search for music on Spotify
  const searchMusic = useCallback(async (query: string) => {
    if (query.trim() === "") {
      setSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    
    try {
      const results = await searchSpotifyTracks(query);
      setSearchResults(results);
    } catch (error) {
      console.error("Error searching Spotify:", error);
    } finally {
      setIsSearching(false);
    }
  }, []);
  
  // Load tracks from a specific focus playlist
  const loadPlaylist = useCallback(async (playlistId: string) => {
    if (!playlistId) return;
    
    setSelectedPlaylistId(playlistId);
    setIsSearching(true);
    
    try {
      const tracks = await getPlaylistTracks(playlistId);
      if (tracks.length > 0) {
        setSpotifyTracks(tracks);
      }
    } catch (error) {
      console.error("Error loading playlist:", error);
    } finally {
      setIsSearching(false);
    }
  }, []);
  
  // Add track to playlist (from search results)
  const addTrack = useCallback((track: Track) => {
    setSpotifyTracks(prev => [...prev, track]);
    // Start playing the track if nothing is playing
    if (currentTrackIndex === null) {
      setCurrentTrackIndex(playlist.length); // New track will be at the end
      setIsPlaying(true);
    }
  }, [currentTrackIndex, playlist.length]);
  
  return {
    currentTrack: currentTrack ? {
      ...currentTrack,
      repeat,
      shuffle,
    } : null,
    playlist,
    isPlaying,
    currentTime,
    duration,
    searchQuery,
    setSearchQuery,
    searchResults,
    isSearching,
    focusPlaylists,
    selectedPlaylistId,
    showInNotification,
    notificationPermission,
    togglePlayPause,
    playNext,
    playPrevious,
    toggleShuffle,
    toggleRepeat,
    updateTime,
    searchMusic,
    loadPlaylist,
    addTrack,
    toggleNotification,
    requestNotificationPermission,
  };
};
