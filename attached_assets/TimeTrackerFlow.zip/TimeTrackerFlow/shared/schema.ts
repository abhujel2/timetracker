import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  title: text("title"),
  focusedTimeToday: integer("focused_time_today").default(0),
  focusedTimeGoal: integer("focused_time_goal").default(0),
  focusedTimePercentage: integer("focused_time_percentage").default(0),
  focusedTimeChange: text("focused_time_change").default("+0%"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  title: true,
});

// Tasks
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull().default("todo"),
  project: text("project"),
  duration: text("duration"),
  progress: integer("progress").default(0),
  dueDate: text("due_date"),
  completedAt: text("completed_at"),
  userId: integer("user_id").notNull(),
  tags: text("tags"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  name: true,
  description: true,
  status: true,
  project: true,
  duration: true,
  progress: true,
  dueDate: true,
  tags: true,
});

// Schedule Events
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  timeRange: text("time_range").notNull(),
  date: text("date").notNull(),
  category: text("category").default("other"),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertEventSchema = createInsertSchema(events).pick({
  title: true,
  description: true,
  timeRange: true,
  date: true,
  category: true,
});

// Music Tracks
export const tracks = pgTable("tracks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  artist: text("artist").notNull(),
  audioUrl: text("audio_url").notNull(),
  coverUrl: text("cover_url"),
  duration: real("duration").notNull(),
  category: text("category").default("productivity"),
});

export const insertTrackSchema = createInsertSchema(tracks).pick({
  title: true,
  artist: true,
  audioUrl: true,
  coverUrl: true,
  duration: true,
  category: true,
});

// Deadlines
export const deadlines = pgTable("deadlines", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  dueDate: text("due_date").notNull(),
  daysLeft: integer("days_left").notNull(),
  progress: integer("progress").default(0),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDeadlineSchema = createInsertSchema(deadlines).pick({
  title: true,
  dueDate: true,
  daysLeft: true,
  progress: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type Track = typeof tracks.$inferSelect;
export type InsertTrack = z.infer<typeof insertTrackSchema>;

export type Deadline = typeof deadlines.$inferSelect;
export type InsertDeadline = z.infer<typeof insertDeadlineSchema>;

// Stats Types (not stored directly in database)
export interface TimeDistribution {
  category: string;
  percentage: number;
  color: string;
}

export interface WeeklyDataPoint {
  day: string;
  totalHours: number;
  productiveHours: number;
}

export interface Stats {
  timeDistribution: TimeDistribution[];
  weeklyData: WeeklyDataPoint[];
  focusScore: number;
  focusScoreChange: string;
  tasksCompleted: string;
  taskCompletionRate: string;
}
